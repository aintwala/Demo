//
//  ViewController.h
//  photoGellary
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>
@import AVFoundation;
@import AVKit;

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet AVPlayer *avPlayer;

@end

