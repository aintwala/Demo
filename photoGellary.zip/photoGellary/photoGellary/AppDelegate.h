//
//  AppDelegate.h
//  photoGellary
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

