//
//  LocationViewController.h
//  photoGellary
//
//  Created by ami on 3/17/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface LocationViewController : UIViewController
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@end
