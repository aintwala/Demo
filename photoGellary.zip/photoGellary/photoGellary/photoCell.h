//
//  photoCell.h
//  photoGellary
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface photoCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;


@end
