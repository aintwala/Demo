//
//  ViewController.m
//  photoGellary
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"
#import <Photos/Photos.h>
#import "photoCell.h"
#import <MediaPlayer/MediaPlayer.h>
#import "AssetBrowserItem.h"
@import AVKit;
@import AVFoundation;

@interface ViewController () <UICollectionViewDelegate, UICollectionViewDataSource>

@end

@implementation ViewController

NSArray *imageArray;
NSMutableArray *mutableArray;
NSArray *videoArray;
NSMutableArray *mutableVideoArray;
NSMutableDictionary *dic;
NSURL *URL;
AVPlayerViewController *playerViewController;
AVPlayer * player;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getAllVideosFromCameraRoll];
    _collectionView.delegate = nil;
    _collectionView.dataSource = nil;
}

-(void)getAllVideosFromCameraRoll {
    
    videoArray=[[NSArray alloc] init];
    mutableVideoArray =[[NSMutableArray alloc]init];
    
    PHVideoRequestOptions *options=[[PHVideoRequestOptions alloc] init];
    options.version = PHVideoRequestOptionsVersionOriginal;
    
    PHFetchResult *result = [PHAsset fetchAssetsWithMediaType:PHAssetMediaTypeVideo options:nil];
    NSLog(@"%d", (int)result.count);
    
    for (PHAsset *asset in result) {
        [[PHImageManager defaultManager] requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset *asset, AVAudioMix *audioMix, NSDictionary *info) {
            if ([asset isKindOfClass:[AVURLAsset class]]) {
                URL = [(AVURLAsset *)asset URL];
                NSLog(@"%@", URL);
                dic = [NSMutableDictionary new];
            [self performSelector:@selector(imageFromVideoURL)];
                [dic setValue:URL forKey:@"VideoUrl"];
                [mutableVideoArray addObject:dic];
                _collectionView.delegate = self;
                _collectionView.dataSource = self;
            }
        }];
    }
}

- (UIImage *)imageFromVideoURL {
    UIImage *image = nil;
    AVAsset *asset = [[AVURLAsset alloc] initWithURL:URL options:nil];;
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    imageGenerator.appliesPreferredTrackTransform = YES;
    Float64 durationSeconds = CMTimeGetSeconds([asset duration]);
    CMTime midpoint = CMTimeMakeWithSeconds(durationSeconds/2.0, 600);
    NSError *error = nil;
    CMTime actualTime;
    CGImageRef halfWayImage = [imageGenerator copyCGImageAtTime:midpoint actualTime:&actualTime error:&error];
    if (halfWayImage != NULL) {
        image = [[UIImage alloc] initWithCGImage:halfWayImage];
        [dic setValue:image forKey:@"ImageThumbnail"];
        NSLog(@"Values of dictonary==>%@", dic);
    }
    return image;
}

//-(void)getAllPhotosFromCamera
//{
//    imageArray=[[NSArray alloc] init];
//    mutableArray =[[NSMutableArray alloc]init];
//    
//    PHImageRequestOptions *requestOptions = [[PHImageRequestOptions alloc] init];
//    requestOptions.resizeMode   = PHImageRequestOptionsResizeModeExact;
//    requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
//    requestOptions.synchronous = true;
//    PHFetchResult *result = [PHAsset fetchAssetsWithMediaType:PHAssetMediaTypeImage options:nil];
//    
//    NSLog(@"%d",(int)result.count);
//    
//    PHImageManager *manager = [PHImageManager defaultManager];
//    NSMutableArray *images = [NSMutableArray arrayWithCapacity:[result count]];
//    
//    // assets contains PHAsset objects.
//    
//    __block UIImage *ima;
//    for (PHAsset *asset in result) {
//        // Do something with the asset
//        
//        [manager requestImageForAsset:asset
//                           targetSize:PHImageManagerMaximumSize
//                          contentMode:PHImageContentModeDefault
//                              options:requestOptions
//                        resultHandler:^void(UIImage *image, NSDictionary *info) {
//                            ima = image;
//                            
//                            [images addObject:ima];
//                        }];
//        
//        
//    }
//    
//    imageArray = [images copy];  // You can direct use NSMutuable Array images
//}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return mutableVideoArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    photoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.imgView.image = [[mutableVideoArray objectAtIndex:indexPath.row] objectForKey:@"ImageThumbnail"];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    playerViewController = [AVPlayerViewController new];
    AVURLAsset *asset = [AVURLAsset assetWithURL: URL];
    AVPlayerItem *item = [AVPlayerItem playerItemWithAsset: asset];
    
    player = [[AVPlayer alloc] initWithPlayerItem: item];
    [self presentViewController:playerViewController animated:YES completion:nil];
    playerViewController.player = player;
    [playerViewController.view setFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    playerViewController.showsPlaybackControls = YES;
    playerViewController.view.frame = self.view.frame;
    [playerViewController.player play];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
