//
//  photoCell.m
//  photoGellary
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

#import "photoCell.h"

@implementation photoCell

@end
