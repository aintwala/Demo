//
//  ViewController.h
//  ExpandableTableView
//
//  Created by ami on 8/24/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *arrayForBool;
    NSArray *sectionTitleArray;
}

@property (strong, nonatomic) IBOutlet UITableView *ExpandableTableView;

@end

