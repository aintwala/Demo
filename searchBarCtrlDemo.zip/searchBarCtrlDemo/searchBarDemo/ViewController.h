//
//  ViewController.h
//  searchBarDemo
//
//  Created by heli on 7/14/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecipeTableCell.h"
@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UISearchControllerDelegate,UISearchResultsUpdating> {
    NSMutableArray *aryData,*filteredContentList;
    BOOL isSearching;
}

@property (strong, nonatomic) IBOutlet UITableView *tblData;
@property (strong, nonatomic) UISearchController *searchController;

@end

