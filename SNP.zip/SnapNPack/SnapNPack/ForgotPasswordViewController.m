//
//  ForgotPasswordViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "ForgotPasswordViewController.h"
#import "ViewController.h"
#import "AppDelegate.h"
#import <MessageUI/MessageUI.h>


@interface ForgotPasswordViewController ()<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>
{
    AppDelegate *appDelegate;
}
@end

@implementation ForgotPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate TxtPadding:self.txtEmail];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBackAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnSubmit:(id)sender
{
    if ( [MFMailComposeViewController canSendMail] )
    {
        [appDelegate.globalMailComposer setToRecipients:@[self.txtEmail.text]];
        [appDelegate.globalMailComposer setSubject:@"Forgot Password"];
        [appDelegate.globalMailComposer setMessageBody:@"Your Password is Dharmesh" isHTML:NO];
        appDelegate.globalMailComposer.mailComposeDelegate = self;
        [self presentViewController:appDelegate.globalMailComposer
                           animated:YES completion:nil];
    }
    else
    {
        [appDelegate cycleTheGlobalMailComposer];
    }
}
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    if (result == MFMailComposeResultSent)
    {
        NSLog(@"\n\n Email Sent");
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
