//
//  BoxDetailViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "BoxDetailViewController.h"
#import "BoxCollectionViewCell.h"
#import "NewBoxViewController.h"
#import "AppDelegate.h"
#import <CoreData/CoreData.h>

@interface BoxDetailViewController ()
{
    NSMutableArray *ArrItemList,*ArrBoxList;
    AppDelegate *appDel;
    float currentPage;
    NSArray *nameArr;
}
@end

@implementation BoxDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    appDel=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    currentPage=0.0f;
    [self.collectionview reloadData];
}
-(void)viewWillAppear:(BOOL)animated
{
    NSManagedObjectContext *managedObjectContext = [appDel managedObjectContext1];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Items"];
    NSFetchRequest *fetchRequest1 =[[NSFetchRequest alloc] initWithEntityName:@"Boxes"];
    NSArray *tarr1=[[managedObjectContext executeFetchRequest:fetchRequest1 error:nil] mutableCopy];
    ArrBoxList=[[NSMutableArray alloc]init];
    for (int i=0; i<tarr1.count; i++) {
        
        if ([[[tarr1 objectAtIndex:i] valueForKey:@"email"] isEqualToString:[NSString stringWithFormat:@"%@",appDel.strEmail]]) {
            
            [ArrBoxList addObject:[tarr1 objectAtIndex:i]];
        }
        
    }
    
    ArrItemList=[[NSMutableArray alloc]init];
    NSArray *tarr = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    
    for (int i=0; i<tarr.count; i++)
    {
        if ([[[tarr objectAtIndex:i] valueForKey:@"email"] isEqualToString:[NSString stringWithFormat:@"%@",appDel.strEmail]]) {
            
            [ArrItemList addObject:[tarr objectAtIndex:i]];
        }

    }
    nameArr = [ArrItemList valueForKey:@"boxname"] ;
    for (int i=0; i<nameArr.count; i++)
    {
        // appdel.strboxname = self.lbl_boxname.text;
        [self.lblBoxName setText:[NSString stringWithFormat:@"%@",[nameArr objectAtIndex:self.pageControl.currentPage]]];
    }
    // self.lblBoxName.text=[NSString stringWithFormat:@"%@",[nameArr objectAtIndex:currentPage]];
    appDel.strBoxname = self.lblBoxName.text;
    
    _pageControl.numberOfPages=ArrItemList.count;
    [self.collectionview reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return ArrItemList.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    BoxCollectionViewCell *cell = [_collectionview dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
     if([ArrItemList count] > 0 && [ArrItemList count] > indexPath.row)
     {
         NSManagedObject *device1 = [ArrItemList objectAtIndex:indexPath.row];
         cell.imgItemBox.image = [UIImage imageWithData:[device1 valueForKey:@"image"]];
     }
    return cell;
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageWidth = _collectionview.frame.size.width;
    currentPage = _collectionview.contentOffset.x / pageWidth;
    if (0.0f != fmodf(currentPage, 1.0f))
    {
        _pageControl.currentPage = currentPage + 1;
        self.lblBoxName.text=[nameArr objectAtIndex:currentPage+1];
    }
    else
    {
        _pageControl.currentPage = currentPage;
        self.lblBoxName.text=[nameArr objectAtIndex:currentPage];
    }
    NSLog(@"finishPage: %ld", _pageControl.currentPage);
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NewBoxViewController *obj = [story instantiateViewControllerWithIdentifier:@"NewBoxViewController"];
    if (![[ArrItemList objectAtIndex:indexPath.row] valueForKey:@"qrstring"])
    {
        obj.isButtonPressed=@"0";

    }
    else
    {
        obj.isButtonPressed=@"1";

    }
    appDel.strBoxname = [nameArr objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:obj animated:YES];
}
- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
