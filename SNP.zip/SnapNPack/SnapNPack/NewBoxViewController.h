//
//  NewBoxViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NewBoxViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property (weak, nonatomic) IBOutlet UILabel *lblBoxName;
@property (strong,nonatomic) NSString *strboxname,*isButtonPressed;
- (IBAction)btnAdd:(id)sender;
- (IBAction)btnConfirm:(id)sender;
- (IBAction)btnBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnConfirmOut;

@end
