//
//  QRCodeListViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "QRCodeListViewController.h"
#import "QRListTableViewCell.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "PrintQRCodeViewController.h"
#import "Global.h"
#import "Constants.h"

@interface QRCodeListViewController ()
{
    AppDelegate *appDel;
    NSArray *nameArr,*filterArr;
    NSMutableArray *ArrList;
    NSMutableArray *tarr;
    int j;
}
@end
@implementation QRCodeListViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    appDel=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    NSManagedObjectContext *managedObjectContext = [appDel managedObjectContext1];
    NSFetchRequest *fetchRequest= [[NSFetchRequest alloc] initWithEntityName:@"Boxes"];
     tarr= [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];

    ArrList = [[NSMutableArray alloc]init];
    for (int i=0;i<tarr.count;i++)
    {
        if ([[[tarr objectAtIndex:i] valueForKey:@"email"] isEqualToString:[NSString stringWithFormat:@"%@",appDel.strEmail]])
        {
            [ArrList addObject:[tarr objectAtIndex:i]];
        }
    }
    nameArr = [ArrList valueForKey:@"boxname"] ;
    filterArr =[ArrList valueForKey:@"qrstring"];
}

- (void)didReceiveMemoryWarning {
 [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ArrList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    QRListTableViewCell *cell = [_tblView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.lblBoxname.text=[NSString stringWithFormat:@"  QR CODE With %@",[nameArr objectAtIndex:indexPath.row]];
    cell.btnPrint.tag=indexPath.row;
    [cell.btnPrint addTarget:self action:@selector(printButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
-(void)printButtonPressed:(UIButton*)sender
{
    NSUInteger i=sender.tag;
    NSLog(@"%ld",(unsigned long)i);
    PrintQRCodeViewController *second=(PrintQRCodeViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"PrintQRCodeViewController"];
    second.strQRCode=[NSString stringWithFormat:@"%@",[filterArr objectAtIndex:i]];
    if ([second.strQRCode isEqualToString:[NSString stringWithFormat:@"(null)"]]){
        [self presentViewController:[Global alertWithTitle:@"Invalid" withMessage:ERROR_QR preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    [self.navigationController pushViewController:second animated:YES];
}
- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];

}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSManagedObjectContext *context1 = [appDel managedObjectContext1];
    
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        //Delete object from database
        NSString *str1=[NSString stringWithFormat:@"%@",[[ArrList valueForKey:@"boxname"] objectAtIndex:indexPath.row]];
        NSString *str2=[NSString stringWithFormat:@"%@",[[tarr valueForKey:@"boxname"] objectAtIndex:indexPath.row]];
        if ([str1 isEqualToString:str2])
        {
            [context1 deleteObject:[ArrList objectAtIndex:indexPath.row]];
            for (int i=0;i<tarr.count;i++)
            {
                [context1 deleteObject:[tarr objectAtIndex:i]];
            }
            NSError *error = nil;
            if (![context1 save:&error])
            {
                NSLog(@"Can't Delete! %@ %@", error, [error localizedDescription]);
                return;
            }
            // Remove device from table view
            [ArrList removeObjectAtIndex:indexPath.row];
            [tarr removeObjectAtIndex:indexPath.row];
            
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
            [self.tblView reloadData];
        }
    }
}
@end
