//
//  ViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "ViewController.h"
#import "RegisterViewController.h"
#import "ForgotPasswordViewController.h"
#import "DashboardViewController.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "Constants.h"
#import "Global.h"
#define _RGB(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

@interface ViewController ()<UITextFieldDelegate>
{
    BOOL isMatch,isNavigate;
    AppDelegate *appDel;
}
@end

@implementation ViewController
@synthesize txtEmail,txtPassword,btnSubmit;
- (void)viewDidLoad {
    [super viewDidLoad];
    Global *sharedManager;
    sharedManager=[Global sharedManager];
    AryUserInfo=[[NSMutableArray alloc]init];
    appDel=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    [appDel TxtPadding:txtEmail];
    [appDel TxtPadding:txtPassword];
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//-(void)viewWillAppear:(BOOL)animated
//{
//    self.txtEmail.text=@"";
//    self.txtPassword.text=@"";
//}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    // Fetch the devices from persistent data store
    NSManagedObjectContext *managedObjectContext = [appDel managedObjectContext1];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"User"];
    AryUserInfo = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
}
- (IBAction)btnLogin:(id)sender
{
    //Save Record In Core Data
    if ([txtEmail.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_EMAIL preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ([txtPassword.text length] < 6)
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_PASSWORD preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else
    {
        NSArray *emailArr = [AryUserInfo valueForKey:@"email"] ;
        NSArray *passArr = [AryUserInfo valueForKey:@"password"];
        
        for (int i=0; i<emailArr.count; i++)
        {
            if ([txtEmail.text isEqualToString:[emailArr objectAtIndex:i]] && [txtPassword.text isEqualToString:[passArr objectAtIndex:i]])
            {
                isMatch=YES;
                appDel.strEmail=txtEmail.text;
            }
        }
        if (isMatch == YES)
        {
            isMatch=NO;
                        NSString *message = @"Successfully Logged in";
            
            
            UIView *tost=[[UIView alloc]initWithFrame:CGRectMake(btnSubmit.frame.origin.x*3, btnSubmit.frame.origin.y*1.5, btnSubmit.frame.size.width*.75, btnSubmit.frame.size.height*.75)];
            
            UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, tost.frame.size.width, tost.frame.size.height)];
            
            tost.layer.masksToBounds = NO;
            tost.layer.shadowOffset = CGSizeMake(0, 10);
            tost.layer.shadowOpacity = 0.5;
            
            lbl.text=message;
            lbl.textColor=[UIColor whiteColor];
            lbl.textAlignment=NSTextAlignmentCenter;
            [tost setBackgroundColor:_RGB(0, 0, 0, .5)];
            
            [self.view addSubview:tost];
            [tost addSubview:lbl];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                
                tost.hidden=YES;
            });
            UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
            DashboardViewController *obj = [story instantiateViewControllerWithIdentifier:@"DashboardViewController"];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1.3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                [self.navigationController pushViewController:obj animated:YES];
            });
            

        }
        else
        {
            [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_LOGIN_ERROR preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
        }
    }
}
- (IBAction)btnRegister:(id)sender
{
    //Navigation
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    RegisterViewController *obj = [story instantiateViewControllerWithIdentifier:@"RegisterViewController"];
    [self.navigationController pushViewController:obj animated:YES];
}
- (IBAction)btnForgotPassword:(id)sender
{
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ForgotPasswordViewController *obj = [story instantiateViewControllerWithIdentifier:@"ForgotPasswordViewController"];
    [self.navigationController pushViewController:obj animated:YES];
}
@end
