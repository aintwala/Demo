//
//  QRListTableViewCell.h
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRListTableViewCell : UITableViewCell
{
    BOOL isbuttonpressed;
}
@property (weak, nonatomic) IBOutlet UIImageView *imgViewCheck;
- (IBAction)btnCheckAction:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblBoxname;

@property (weak, nonatomic) IBOutlet UIButton *btnPrint;

@end
