//
//  Global.m
//  SnapNPack
//
//  Created by dharmesh on 8/26/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "Global.h"
#import <UIKit/UIKit.h>

@implementation Global
+ (id)sharedManager {
    static Global *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    
    return sharedMyManager;
}

+(UIAlertController*)alertWithTitle: (NSString *) title withMessage: (NSString*) message preferredStyle:(UIAlertControllerStyle)preferredStyle
{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle: preferredStyle];
    UIAlertAction *ok =[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){}];
    [alert addAction:ok];
    return alert;
}
@end
