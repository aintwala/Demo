//
//  BoxDetailViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BoxDetailViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionview;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;
- (IBAction)btnBack:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblBoxName;

@end
