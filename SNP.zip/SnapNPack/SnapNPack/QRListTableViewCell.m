//
//  QRListTableViewCell.m
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "QRListTableViewCell.h"

@implementation QRListTableViewCell

- (void)awakeFromNib {
    isbuttonpressed = true;
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnCheckAction:(id)sender
{
    
    if (isbuttonpressed) {
        
        self.imgViewCheck.image = [UIImage imageNamed:@"Check"];
        
        isbuttonpressed = false;
        
    }
    else {
        
        
          self.imgViewCheck.image = [UIImage imageNamed:@"Uncheckbox"];
        isbuttonpressed =true;
        
    }
    
}
- (IBAction)btnInfo:(id)sender
{
    
}
@end
