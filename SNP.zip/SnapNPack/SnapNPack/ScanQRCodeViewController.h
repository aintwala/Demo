//
//  ScanQRCodeViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanQRCodeViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imgQRView;
- (IBAction)btnScanQRAct:(id)sender;
- (IBAction)btnBack:(id)sender;
@end
