//
//  PrintQRCodeViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "PrintQRCodeViewController.h"
#include "DashboardViewController.h"
#import <CoreText/CoreText.h>
#import "AppDelegate.h"

@interface PrintQRCodeViewController ()
{
    NSData *stringData;
    CIImage *qrImage;
    AppDelegate *appDel;
    NSString *strFile;
    NSMutableArray *ArrList;
    NSArray *imageArray;
    CIFilter *qrFilter;
}
@end

@implementation PrintQRCodeViewController
@synthesize webView;
- (void)viewDidLoad
{
    [super viewDidLoad];
    webView.hidden=YES;
    appDel =(AppDelegate *)[[UIApplication sharedApplication]delegate];

    self.lblQRCode.text=_strQRCode;
    NSArray *myArray=[_strQRCode componentsSeparatedByString:@" |"];
    strFile = [myArray objectAtIndex:0];
    stringData = [_strQRCode dataUsingEncoding: NSUTF8StringEncoding];
    
    qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    [qrFilter setValue:stringData forKey:@"inputMessage"];
    
    [qrFilter setValue:@"H" forKey:@"inputCorrectionLevel"];
    
    qrImage = qrFilter.outputImage;
    
    float scaleX = _imgQRView.frame.size.width / qrImage.extent.size.width;
    
    float scaleY = _imgQRView.frame.size.height / qrImage.extent.size.height;
    qrImage = [qrImage imageByApplyingTransform:CGAffineTransformMakeScale(scaleX, scaleY)];
    _imgQRView.image = [UIImage imageWithCIImage:qrImage
                        scale:[UIScreen mainScreen].scale
                        orientation:UIImageOrientationUp];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnPrintQRAct:(id)sender
{
    NSString *fileName = [NSString stringWithFormat:@"%@.pdf",strFile];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *pdfFileName = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    [self generatePdfWithFilePath:pdfFileName];
    webView.hidden=NO;
    NSURL *url = [NSURL fileURLWithPath:pdfFileName];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [webView setScalesPageToFit:YES];
    [webView loadRequest:request];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self
               action:@selector(aMethod)
     forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"Done" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor colorWithRed:229/255.0 green:83/255.0 blue:38/255.0 alpha:1];
    [button.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:20]];
    button.frame = CGRectMake(30, 420, 320, 50);
    button.layer.cornerRadius = 10.0f;
    [webView addSubview:button];
    
    UILabel *fromLabel = [[UILabel alloc]initWithFrame:CGRectMake(120, 60, 300 , 60)];
    fromLabel.text =strFile;
    fromLabel.backgroundColor = [UIColor clearColor];
    fromLabel.textColor = [UIColor blackColor];
    [webView addSubview:fromLabel];

}
- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnDoneAct:(id)sender
{
    DashboardViewController *second=(DashboardViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"DashboardViewController"];
    [self.navigationController pushViewController:second animated:YES];
}
-(void)aMethod
{
    webView.hidden=YES;
}
- (void) generatePdfWithFilePath: (NSString *)thefilePath
{
    UIGraphicsBeginPDFContextToFile(thefilePath, CGRectZero, nil);
    
    NSInteger currentPage = 0;
    BOOL done = NO;
    do
    {
        // Mark the beginning of a new page.
        UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, 320,568), nil);
        
        // Draw a page number at the bottom of each page.
        currentPage++;
        //Draw an image
        [self drawImage];
        done = YES;
    }
    while (!done);
    
    // Close the PDF context and write the contents out.
    UIGraphicsEndPDFContext();
}

- (void) drawImage
{
    stringData = [_strQRCode dataUsingEncoding: NSUTF8StringEncoding];
    
    qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    [qrFilter setValue:stringData forKey:@"inputMessage"];
    
    [qrFilter setValue:@"H" forKey:@"inputCorrectionLevel"];
    
    qrImage = qrFilter.outputImage;
    
    float scaleX = _imgQRView.frame.size.width / qrImage.extent.size.width;
    
    float scaleY = _imgQRView.frame.size.height / qrImage.extent.size.height;
    qrImage = [qrImage imageByApplyingTransform:CGAffineTransformMakeScale(scaleX, scaleY)];
    //_imgQRView.image = [UIImage imageWithCIImage:qrImage
    //scale:[UIScreen mainScreen].scale
    //orientation:UIImageOrientationUp];
    UIImage * demoImage = [UIImage imageWithCIImage:qrImage
                                              scale:[UIScreen mainScreen].scale
                                        orientation:UIImageOrientationUp];
    [demoImage drawInRect:CGRectMake(100,100,101,101)];
}

@end
