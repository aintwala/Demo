//
//  PrintQRCodeViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrintQRCodeViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgQRView;
- (IBAction)btnPrintQRAct:(id)sender;
- (IBAction)btnBack:(id)sender;
@property (strong,nonatomic)NSString *strQRCode,*isCellPressed;
@property (weak, nonatomic) IBOutlet UIButton *btnDone;
@property (weak, nonatomic) IBOutlet UILabel *lblQRCode;
- (IBAction)btnDoneAct:(id)sender;
@property (weak, nonatomic) IBOutlet UIWebView *webView;


@end
