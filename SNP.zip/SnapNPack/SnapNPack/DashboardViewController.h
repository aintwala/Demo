//
//  DashboardViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface DashboardViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgPackBox;
- (IBAction)btnPackBox:(id)sender;
- (IBAction)btnUnpackBox:(id)sender;
- (IBAction)btnQRPrint:(id)sender;
- (IBAction)btnLogout:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *viewBoxName;
- (IBAction)btnOK:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtBoxName;
@property (weak, nonatomic) IBOutlet UIButton *btnPackBoxOut;

@end
