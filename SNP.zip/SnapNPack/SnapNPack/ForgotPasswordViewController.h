//
//  ForgotPasswordViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
@interface ForgotPasswordViewController : UIViewController
- (IBAction)btnBackAction:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
- (IBAction)btnSubmit:(id)sender;

@end
