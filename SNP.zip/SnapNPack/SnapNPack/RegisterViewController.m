//
//  RegisterViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "RegisterViewController.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "Global.h"
#import "Constants.h"

@interface RegisterViewController ()
{
    NSMutableArray *AryUserInfo;
    AppDelegate *appDel;
    BOOL isCK;
}
@end

@implementation RegisterViewController
@synthesize txtFirstName,txtLastName,txtEmail,txtPassword,txtConfirmPassword;
- (void)viewDidLoad
{
    [super viewDidLoad];
    appDel=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    isCK=YES;
    [appDel TxtPadding:self.txtFirstName];
    [appDel TxtPadding:self.txtLastName];
    [appDel TxtPadding:self.txtEmail];
    [appDel TxtPadding:self.txtPassword];
    [appDel TxtPadding:self.txtConfirmPassword];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    // Fetch the devices from persistent data store
    NSManagedObjectContext *managedObjectContext = [appDel managedObjectContext1];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"User"];
    
    AryUserInfo = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnSubmitAction:(id)sender
{
    if ([self.txtFirstName.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_FIRST_NAME preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ([self.txtLastName.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_LAST_NAME preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ([self.txtEmail.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_EMAIL preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ([self.txtPassword.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_PASSWORD preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ((self.txtPassword.text.length) < 8)
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_PASSWORD preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ((self.txtConfirmPassword.text.length) < 8)
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_PASSWORD preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if (![self.txtConfirmPassword.text isEqualToString:self.txtPassword.text])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_CONFIRM_PASSWORD preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else
    {
        NSArray *emailArr = [AryUserInfo valueForKey:@"email"] ;
        for (int i=0; i<emailArr.count; i++)
        {
            if (![self.txtEmail.text isEqualToString:[emailArr objectAtIndex:i]])
            {
                isCK=YES;
            }
        }
        if (isCK==YES) {
            NSManagedObjectContext *context = [appDel managedObjectContext];
            
            // Create a new device
            NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"User" inManagedObjectContext:context];
            
            [newDevice setValue:self.txtFirstName.text forKey:@"firstname"];
            [newDevice setValue:self.txtLastName.text forKey:@"lastname"];
            [newDevice setValue:self.txtEmail.text forKey:@"email"];
            [newDevice setValue:self.txtPassword.text forKey:@"password"];
            NSLog(@"%@",newDevice);
            
            NSManagedObjectID *id=[newDevice objectID];
            int yourManagedObject_PK = [[[[[id URIRepresentation] absoluteString] lastPathComponent] substringFromIndex:1] intValue];
            NSLog(@"%d",yourManagedObject_PK);
            [self.navigationController popToRootViewControllerAnimated:YES];
            NSError *error = nil;
            // Save the object to persistent store
            if (![context save:&error])
            {
                NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
            }
        }
        else
        {
            [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_REGISTER preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
        }
    }
}
@end
