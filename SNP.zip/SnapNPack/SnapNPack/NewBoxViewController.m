//
//  NewBoxViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "NewBoxViewController.h"
#import "NewTableViewCell.h"
#import "NewItemViewController.h"
#import <CoreData/CoreData.h>
#import "PrintQRCodeViewController.h"
#import "AppDelegate.h"

@interface NewBoxViewController ()
{
    NSMutableArray *ArrList;
    AppDelegate *appDel;
    NSString *strqr;
}
@end
@implementation NewBoxViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    appDel=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    self.tblView.separatorColor = [UIColor clearColor];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if ([_isButtonPressed isEqualToString:@"1"])
    {
        _btnConfirmOut.hidden=YES;
    }
    self.lblBoxName.text=appDel.strBoxname;
    // Fetch the devices from persistent data store
    NSManagedObjectContext *managedObjectContext = [appDel managedObjectContext1];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Items"];
    ArrList=[[NSMutableArray alloc]init];
    NSArray *tarr = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    for (int i=0; i<tarr.count; i++)
    {
        if ([[[tarr objectAtIndex:i] valueForKey:@"email"] isEqualToString:[NSString stringWithFormat:@"%@",appDel.strEmail]] && [[[tarr objectAtIndex:i] valueForKey:@"boxname"] isEqualToString:[NSString stringWithFormat:@"%@",appDel.strBoxname]]) {
            
            [ArrList addObject:[tarr objectAtIndex:i]];
        }
    }
    if (![appDel.setEmptyBox isEqualToString:@"yes"])
    {
        [self.tblView reloadData];
    }
    else
    {
        appDel.setEmptyBox=@"no";
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([appDel.setEmptyBox isEqualToString:@"yes"])
    {
        return 0;
    }
    else
    {
        return ArrList.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    NewTableViewCell *cell = [_tblView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    NSManagedObject *device = [ArrList objectAtIndex:indexPath.row];
    
    [cell.lblItemName setText:[NSString stringWithFormat:@"%@", [device valueForKey:@"itemname"]]];
    [cell.txtItemDesckView setText:[NSString stringWithFormat:@"%@", [device valueForKey:@"comments"]]];
    cell.imgView.image = [UIImage imageWithData:[device valueForKey:@"image"]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NewItemViewController *obj = [story instantiateViewControllerWithIdentifier:@"NewItemViewController"];
    NSManagedObject *device = [ArrList objectAtIndex:indexPath.row];
    obj.strItem=[NSString stringWithFormat:@"%@", [device valueForKey:@"itemname"]];
    obj.strComment= [NSString stringWithFormat:@"%@", [device valueForKey:@"comments"]];
    obj.strImage=[NSData dataWithData:[device valueForKey:@"image"]];

    [self.navigationController pushViewController:obj animated:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSManagedObjectContext *context = [appDel managedObjectContext1];

    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete object from database
        [context deleteObject:[ArrList objectAtIndex:indexPath.row]];

        NSError *error = nil;
        if (![context save:&error]) {
            NSLog(@"Can't Delete! %@ %@", error, [error localizedDescription]);
            return;
        }

        // Remove device from table view
        [ArrList removeObjectAtIndex:indexPath.row];
        [self.tblView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

- (IBAction)btnAdd:(id)sender
{
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NewItemViewController *obj = [story instantiateViewControllerWithIdentifier:@"NewItemViewController"];
    
    [self.navigationController pushViewController:obj animated:YES];
    
    obj.setFG=@"1";
}

- (IBAction)btnConfirm:(id)sender
{
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSLog(@"System Date is %@",[dateFormatter stringFromDate:[NSDate date]]);
    strqr=[NSString stringWithFormat:@"%@ | %@",appDel.strBoxname,[dateFormatter stringFromDate:[NSDate date]]];
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PrintQRCodeViewController *obj = [story instantiateViewControllerWithIdentifier:@"PrintQRCodeViewController"];

    NSManagedObjectContext *context = [appDel managedObjectContext1];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"Boxes" inManagedObjectContext:context]];
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:request error:&error];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"boxname == %@", appDel.strBoxname];
    [request setPredicate:predicate];
    
    NSInteger j = 0;
    for (int i=0; i<results.count; i++)
    {
        if ([appDel.strBoxname isEqualToString:[NSString stringWithFormat:@"%@",[[results objectAtIndex:i]valueForKey:@"boxname"]]])
        {
            j=i;
        }
    }
    
    NSManagedObject* manageObject = [results objectAtIndex:j];
    [manageObject setValue:strqr forKey:@"qrstring"];
    [manageObject setValue:appDel.strBoxname forKey:@"boxname"];
    [manageObject setValue:appDel.strEmail forKey:@"email"];
    
    [context save:nil];
    obj.strQRCode=strqr;
    appDel.strQR=strqr;
    _isButtonPressed = @"1";
    [self.navigationController pushViewController:obj animated:YES];
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
