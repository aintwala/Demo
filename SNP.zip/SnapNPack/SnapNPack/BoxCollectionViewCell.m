//
//  BoxCollectionViewCell.m
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "BoxCollectionViewCell.h"

@implementation BoxCollectionViewCell

@end
