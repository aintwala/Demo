//
//  ViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface ViewController : UIViewController
{
    NSMutableArray *AryUserInfo;
}
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)btnLogin:(id)sender;
- (IBAction)btnRegister:(id)sender;
- (IBAction)btnForgotPassword:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;

@end

