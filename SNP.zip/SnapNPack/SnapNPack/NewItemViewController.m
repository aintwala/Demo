//
//  NewItemViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "NewItemViewController.h"
#import "NewBoxViewController.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "Global.h"
#import "Constants.h"

@interface NewItemViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    NSData *dataImage;
    AppDelegate *appDelegate;
    BOOL isbuttonpressed;
}
@end

@implementation NewItemViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    isbuttonpressed=true;
    appDelegate=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    [appDelegate TxtPadding:self.txtBoxName];
    self.txtCommentView.text = @"Add Comment";
    self.txtCommentView.textColor = [UIColor lightGrayColor];
    if (![self.setFG isEqualToString:@"1"])
    {
        [self.imgBoxView setImage:[UIImage imageWithData:_strImage]];
        self.txtBoxName.text=[NSString stringWithFormat:@"%@",_strItem];
        self.txtCommentView.text=[NSString stringWithFormat:@"%@",_strComment];
        self.btnDone.hidden=YES;
        self.txtBoxName.userInteractionEnabled=false;
        self.txtCommentView.userInteractionEnabled=false;
        self.btnDone.hidden = YES;
        self.btnImageActionsheet.hidden=YES;
    }
    
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.txtCommentView.text = @"";
    self.txtCommentView.textColor = [UIColor blackColor];
}
-(void) textViewDidChange:(UITextView *)textView
{
    if(self.txtCommentView.text.length == 0)
    {
        self.txtCommentView.textColor = [UIColor lightGrayColor];
        self.txtCommentView.text = @"Add Comment";
        [self.txtCommentView resignFirstResponder];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnCheckAction:(id)sender
{
    if (isbuttonpressed)
    {
        [self.btnCheckUncheck setImage:[UIImage imageNamed:@"CheckBox"] forState:UIControlStateNormal];
        isbuttonpressed = false;
        
    }
    else
    {
        [self.btnCheckUncheck setImage:[UIImage imageNamed:@"Uncheckbox"] forState:UIControlStateNormal];
        isbuttonpressed =true;
    }
}
- (IBAction)btnBack:(id)sender
{
    appDelegate.setEmptyBox=@"yes";
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnDone:(id)sender
{
    if ([self.txtBoxName.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_ITEM preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if ([self.txtCommentView.text isEqualToString:@""] || [self.txtCommentView.text isEqualToString:@"Add Comment"]) {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_COMMENT preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else if (!dataImage)
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_IMAGE preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
    else
    {
        NSManagedObjectContext *context = [appDelegate managedObjectContext1];
        NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Items" inManagedObjectContext:context];
        [newDevice setValue:self.txtBoxName.text forKey:@"itemname"];
        [newDevice setValue:self.txtCommentView.text forKey:@"comments"];
        [newDevice setValue:dataImage forKey:@"image"];
        [newDevice setValue:appDelegate.strEmail forKey:@"email"];
        [newDevice setValue:appDelegate.strBoxname forKey:@"boxname"];

        NSError *error = nil;
        // Save the object to persistent store
        if (![context save:&error]) {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }
        [self.navigationController popViewControllerAnimated:YES];
        
    }
    
}
- (void)takeNewPhotoFromCamera
{
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.allowsEditing = YES;
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:nil];
    }
    else
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_CAMERA preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];
    }
}
-(void)choosePhotoFromExistingImages
{
    
    UIImagePickerController *pickerLibrary = [[UIImagePickerController alloc] init];
    pickerLibrary.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    pickerLibrary.delegate = self;
    [self presentViewController:pickerLibrary animated:YES completion:nil];
    
}
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    // UIImage *myImage = image;
    
    _imgBoxView.image=image;
    UIImage *myImage = _imgBoxView.image;
    
    dataImage = UIImageJPEGRepresentation(myImage, 0.0);
    
    //  dataImage = UIImagePNGRepresentation(myImage);
    
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = [NSDate dateWithTimeIntervalSinceNow:1];
    localNotification.alertBody = @"Your alert message";
    localNotification.timeZone = [NSTimeZone defaultTimeZone];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)btnImageActionSheet:(id)sender
{
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"Choose Photo" message:@"Using the alert controller" preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped.
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Take Photo With Camera" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        
        
        [self takeNewPhotoFromCamera];
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Select Photo From Library" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self choosePhotoFromExistingImages];
    }]];
    [self presentViewController:actionSheet animated:YES completion:nil];
    
}
@end
