//
//  DashboardViewController.m
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import "DashboardViewController.h"
#import "NewBoxViewController.h"
#import "QRCodeListViewController.h"
#import "BoxDetailViewController.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "Constants.h"
#import "Global.h"

@interface DashboardViewController ()
{
    UITapGestureRecognizer *tapRecognizer;
    AppDelegate *appDelegate;
    NSArray *nameArr;
    NSMutableArray *ArrList;
}
@end

@implementation DashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    appDelegate=((AppDelegate*)[[UIApplication sharedApplication] delegate]);
    tapRecognizer=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissVIEW)];
    [self.view addGestureRecognizer:tapRecognizer];
     self.btnPackBoxOut.hidden = NO;
    self.imgPackBox.hidden=NO;
    

    NSManagedObjectContext *managedObjectContext1 = [appDelegate managedObjectContext1];
    NSFetchRequest *fetchRequest1= [[NSFetchRequest alloc] initWithEntityName:@"Boxes"];
    NSArray *tarr = [[managedObjectContext1 executeFetchRequest:fetchRequest1 error:nil] mutableCopy];
    ArrList=[[NSMutableArray alloc]init];
    for (int i=0;i<tarr.count;i++)
    {
        if ([[[tarr objectAtIndex:i] valueForKey:@"email"] isEqualToString:[NSString stringWithFormat:@"%@",appDelegate.strEmail]])
        {
            [ArrList addObject:[tarr objectAtIndex:i]];
        }
    }
    nameArr = [ArrList valueForKey:@"boxname"] ;
}

-(void)viewWillAppear:(BOOL)animated
{
    self.viewBoxName.hidden=YES;
}
-(void)dismissVIEW
{
    self.viewBoxName.hidden = YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnPackBox:(id)sender
{
    [appDelegate TxtPadding:self.txtBoxName];
    self.viewBoxName.hidden=NO;
    self.txtBoxName.text=@"";
    self.viewBoxName.transform = CGAffineTransformMakeScale(0.01, 0.01);
    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.viewBoxName.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished){
        
        // if you want to do something once the animation finishes, put it here
    }];

    }
- (IBAction)btnUnpackBox:(id)sender
{
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];

    BoxDetailViewController *obj = [story instantiateViewControllerWithIdentifier:@"BoxDetailViewController"];
    [self.navigationController pushViewController:obj animated:YES];

}

- (IBAction)btnQRPrint:(id)sender
{
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    QRCodeListViewController *obj = [story instantiateViewControllerWithIdentifier:@"QRCodeListViewController"];
    [self.navigationController pushViewController:obj animated:YES];

}

- (IBAction)btnLogout:(id)sender
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (IBAction)btnOK:(id)sender
{
    
    if ([self.txtBoxName.text isEqualToString:@""])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_REGISTER preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];

    }
    else if([nameArr containsObject:self.txtBoxName.text])
    {
        [self presentViewController:[Global alertWithTitle:@"Error" withMessage:ERROR_BOX_EXISTS preferredStyle:UIAlertControllerStyleAlert] animated:YES completion:NULL];

    }
    else
    {
        NSManagedObjectContext *context = [appDelegate managedObjectContext1];
        NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Boxes" inManagedObjectContext:context];
        [newDevice setValue:self.txtBoxName.text forKey:@"boxname"];
    
        [newDevice setValue:appDelegate.strEmail forKey:@"email"];
        appDelegate.strBoxname=self.txtBoxName.text;
        NSError *error = nil;
        // Save the object to persistent store
        if (![context save:&error])
        {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }
    
        self.viewBoxName.hidden=YES;
        UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
        NewBoxViewController *obj = [story instantiateViewControllerWithIdentifier:@"NewBoxViewController"];
        appDelegate.setEmptyBox=@"yes";
        obj.strboxname=self.txtBoxName.text;
        [self.navigationController pushViewController:obj animated:YES];
    }
}
@end
