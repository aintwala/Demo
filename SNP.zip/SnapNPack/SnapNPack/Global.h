//
//  Global.h
//  SnapNPack
//
//  Created by dharmesh on 8/26/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Global : NSObject
+ (id)sharedManager;
+(UIAlertController*)alertWithTitle: (NSString *) title withMessage: (NSString*) message preferredStyle:(UIAlertControllerStyle)preferredStyle;
@end
