//
//  Constants.h
//  Contento
//
//  Created by Aadil on 28/10/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#define Constants_h
#import "Global.h"

// For Validation Messages
#define ERROR_FIRST_NAME @"Please Enter Valid First Name."
#define ERROR_LAST_NAME @"Please Enter Valid Last Name."
#define ERROR_EMAIL @"Please enter Valid Email Address."
#define ERROR_PASSWORD @"Please enter Valid Password of minimum 8 characters"
#define ERROR_CONFIRM_PASSWORD @"Please enter Valid Password and Password & Confirm Password should be same"
#define ERROR_USER_REGISTRATION @"User Registration Failed"
#define ERROR_LOGIN_ERROR @"User Login Failed"
#define ERROR_ITEM @"Please Enter Valid Item Name"
#define ERROR_COMMENT @"Please Enter Comment"
#define ERROR_BOX @"Please Enter valid Box name"
#define ERROR_BOX_EXISTS @"Box Name Already Exists"
#define ERROR_IMAGE @"Please Select Image"
#define ERROR_REGISTER @"User Already Exists"
#define ERROR_CAMERA @"Camera Not Available"
#define ERROR_QR @"For this Box , QR Code Not generated Yet"