//
//  AppDelegate.h
//  SnapNPack
//
//  Created by dharmesh on 8/12/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <MessageUI/MessageUI.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext,*managedObjectContext1;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;
@property (strong,nonatomic) NSString *strEmail,*setEmptyBox,*strBoxname,*strQR;
-(void)TxtPadding:(UITextField*)textField;
@property (nonatomic, strong) MFMailComposeViewController *globalMailComposer;
-(void)cycleTheGlobalMailComposer;
@end

