//
//  NewItemViewController.h
//  SnapNPack
//
//  Created by dharmesh on 8/16/16.
//  Copyright © 2016 dharmesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface NewItemViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtBoxName;
@property (weak, nonatomic) IBOutlet UIImageView *imgBoxView;
- (IBAction)btnCheckAction:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *txtCommentView;
- (IBAction)btnBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnDone;
@property (weak, nonatomic) IBOutlet UIButton *btnImageActionsheet;
@property (weak, nonatomic) IBOutlet UIButton *btnCheckUncheck;

- (IBAction)btnDone:(id)sender;
- (IBAction)btnImageActionSheet:(id)sender;
@property (strong) NSManagedObject *device;
@property (strong,nonatomic) NSString *strItem,*strComment,*setFG;
@property (strong,nonatomic) NSData *strImage;
@property(nonatomic,strong) id <UINavigationControllerDelegate, UIImagePickerControllerDelegate> delegate;
@end
