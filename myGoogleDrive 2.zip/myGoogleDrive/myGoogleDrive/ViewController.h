//
//  ViewController.h
//  myGoogleDrive
//
//  Created by krutagn on 2/17/17.
//  Copyright © 2017 Zaptech Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GTMOAuth2ViewControllerTouch.h"
#import "GTLDrive.h"

@interface ViewController : UIViewController

@property (nonatomic, strong) GTLServiceDrive *service;
@property (nonatomic, strong) UITextView *output;

- (IBAction)btnGDrive:(id)sender;

@end

