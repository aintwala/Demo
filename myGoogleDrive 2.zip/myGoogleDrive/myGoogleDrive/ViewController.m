//
//  ViewController.m
//  myGoogleDrive
//
//  Created by krutagn on 2/17/17.
//  Copyright © 2017 Zaptech Solutions. All rights reserved.
//

#import "ViewController.h"
#import "TableVC.h"

static NSString *const kKeychainItemName = @"Drive API";
static NSString *const kClientID = @"709207149709-ji3gmrdvavd93r268ni6p3vg0r19m7q8.apps.googleusercontent.com";
static NSString *const kClientSecret = @"3khRO33vwYeWN2ASShpxgovN";
//Client Secret
//tGm-p5kugJ696D8sc8IvmYiH
@interface ViewController ()
{
  

}

@end

@implementation ViewController
@synthesize service = _service;
@synthesize output = _output;

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)btnGDrive:(id)sender {
    if (!self.service.authorizer.canAuthorize) {
        [self presentViewController:[self createAuthController] animated:YES completion:nil];
    }
    else {
    [self signinAction];
    }
}

-(void)signinAction {
    self.output = [[UITextView alloc] initWithFrame:self.view.bounds];
    self.output.editable = false;
    self.output.contentInset = UIEdgeInsetsMake(20.0, 0.0, 20.0, 0.0);
    self.output.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:self.output];
    self.service = [[GTLServiceDrive alloc] init];
    self.service.authorizer =
    [GTMOAuth2ViewControllerTouch authForGoogleFromKeychainForName:kKeychainItemName clientID:kClientID clientSecret:nil];
}

// Construct a query to get names and IDs of 10 files using the Google Drive API.
//- (void)fetchFiles {
//    self.output.text = @"Getting files...";
//    GTLQueryDrive *query =
//    [GTLQueryDrive queryForFilesList];
//    query.pageSize = 10;
//    query.fields = @"nextPageToken, files(id, name)";
//    [self.service executeQuery:query
//                      delegate:self
//             didFinishSelector:@selector(displayResultWithTicket:finishedWithObject:error:)];
//}

// Process the response and display output.
//- (void)displayResultWithTicket:(GTLServiceTicket *)ticket
//             finishedWithObject:(GTLDriveFileList *)response
//                          error:(NSError *)error {
//    if (error == nil) {
//        NSMutableString *filesString = [[NSMutableString alloc] init];
//        if (response.files.count > 0) {
//            [filesString appendString:@"Files:\n"];
//            for (GTLDriveFile *file in response.files) {
//                [filesString appendFormat:@"%@ (%@)\n", file.name, file.identifier];
//            }
//        } else {
//            [filesString appendString:@"No files found."];
//        }
//        self.output.text = filesString;
//    } else {
//        [self showAlert:@"Error" message:error.localizedDescription];
//    }
//}

- (GTMOAuth2ViewControllerTouch *)createAuthController {
    GTMOAuth2ViewControllerTouch *authController;
    NSArray *scopes = [NSArray arrayWithObjects:kGTLAuthScopeDriveMetadataReadonly, nil];
    authController = [[GTMOAuth2ViewControllerTouch alloc] initWithScope:[scopes componentsJoinedByString:@" "] clientID:kClientID clientSecret:nil keychainItemName:kKeychainItemName delegate:self finishedSelector:@selector(viewController:finishedWithAuth:error:)];
    return authController;
}

- (void)viewController:(GTMOAuth2ViewControllerTouch *)viewController
      finishedWithAuth:(GTMOAuth2Authentication *)authResult
                 error:(NSError *)error {
    if (error != nil) {
        [self showAlert:@"Authentication Error" message:error.localizedDescription];
        self.service.authorizer = nil;
        UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
        TableVC *objVC = [story instantiateViewControllerWithIdentifier:@"TableVC"];
        [[self navigationController] pushViewController:objVC animated:YES];
    }
    else {
        self.service.authorizer = authResult;
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
         [alert dismissViewControllerAnimated:YES completion:nil];
     }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
