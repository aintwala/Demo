//
//  main.m
//  myGoogleDrive
//
//  Created by krutagn on 2/17/17.
//  Copyright © 2017 Zaptech Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
