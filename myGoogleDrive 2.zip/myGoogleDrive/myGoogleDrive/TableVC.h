//
//  TableVC.h
//  myGoogleDrive
//
//  Created by krutagn on 2/17/17.
//  Copyright © 2017 Zaptech Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GTMOAuth2ViewControllerTouch.h"
#import "GTLDrive.h"

@interface TableVC : UIViewController<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tblView;

@property (nonatomic, retain) GTLServiceDrive *service;

@end
