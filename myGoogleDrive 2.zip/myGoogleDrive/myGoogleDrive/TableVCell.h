//
//  TableVCell.h
//  myGoogleDrive
//
//  Created by krutagn on 2/17/17.
//  Copyright © 2017 Zaptech Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableVCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end
