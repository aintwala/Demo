//
//  ViewController.m
//  DropBoxDemo
//
//  Created by ashish on 11/28/16.
//  Copyright © 2016 ashish. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () {
    NSString *strDocumentsDirectory, *strDropBoxFilePath;

}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dropboxLoginDone) name:@"OPEN_DROPBOX_VIEW" object:nil];

    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] == nil)
    {
        [[DBSession sharedSession] linkFromController:self];

    }
    else if (![[DBSession sharedSession] isLinked]) {
        [[DBSession sharedSession] linkFromController:self];
    }
    else{
        
        if (!_strLoadData) {
            _strLoadData = @"";
        }
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"DropBox is already linked." delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];

        [self performSelector:@selector(fetchAllDropboxData) withObject:nil afterDelay:5];
    }

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - dropbox mehtods starts
- (DBRestClient *)restClient
{
    if (restClient == nil) {
        restClient = [[DBRestClient alloc] initWithSession:[DBSession sharedSession]];
        restClient.delegate = self;
    }
    return restClient;
}

-(void)fetchAllDropboxData
{
    if (!_strLoadData) {
        _strLoadData = @"";
    }
    [self.restClient loadMetadata:_strLoadData];
}


#pragma mark - DBRestClientDelegate Methods for Load Data
- (void)restClient:(DBRestClient*)client loadedMetadata:(DBMetadata *)metadata
{
    for (int i = 0; i < [metadata.contents count]; i++) {
        DBMetadata *data = [metadata.contents objectAtIndex:i];
        NSLog(@"%@",data.filename);
    }
}

- (void)restClient:(DBRestClient *)client loadMetadataFailedWithError:(NSError *)error
{
}

#pragma mark - DBRestClientDelegate Methods for Download Data
- (void)restClient:(DBRestClient*)client loadedFile:(NSString*)destPath
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@""
                                                   message:@"File download successfully."
                                                  delegate:nil
                                         cancelButtonTitle:@"Ok"
                                         otherButtonTitles:nil];
    [alert show];
    
}

-(void)restClient:(DBRestClient *)client loadFileFailedWithError:(NSError *)error
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@""
                                                   message:[error localizedDescription]
                                                  delegate:nil
                                         cancelButtonTitle:@"Ok"
                                         otherButtonTitles:nil];
    [alert show];
}

-(void)dropboxLoginDone
{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"dropbox"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    [self performSelector:@selector(fetchAllDropboxData) withObject:nil afterDelay:5];

    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"User logged in successfully." delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [alert show];
}

-(void)downloadFileFromDropBox:(NSString *)filePath
{
    
    strDropBoxFilePath = [NSString stringWithFormat:@"%@",[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[filePath lastPathComponent]]];
    
    [self.restClient loadFile:filePath intoPath:strDropBoxFilePath];
    NSLog(@"%@",strDropBoxFilePath);
}

#pragma mark - File Download Method
-(void)fileDownloadFromDropBox:(id)sender
{
    UIButton *btnDownload = (UIButton *)sender;
    [self performSelector:@selector(downloadFileFromDropBox:) withObject:[btnDownload titleForState:UIControlStateDisabled] afterDelay:.1];
}




@end
