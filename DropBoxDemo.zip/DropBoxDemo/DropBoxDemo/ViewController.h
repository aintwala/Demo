//
//  ViewController.h
//  DropBoxDemo
//
//  Created by ashish on 11/28/16.
//  Copyright © 2016 ashish. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DropboxSDK/DropboxSDK.h>

@interface ViewController : UIViewController <DBRestClientDelegate>
{
    DBRestClient *restClient;

}
@property (nonatomic, readonly) DBRestClient *restClient;
@property (nonatomic, strong) NSString *strLoadData;

@end

