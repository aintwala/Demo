//
//  practiceAppDelegate.h
//  localNotifications

//  Created by jayati on 7/19/16.
//  Copyright © 2016 com.zapsolution. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface practiceAppDelegate : UIResponder <UIApplicationDelegate>
{
    int badgCount;
}
@property (strong, nonatomic) UIWindow *window;

@end
