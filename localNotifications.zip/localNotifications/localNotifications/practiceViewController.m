//
//  practiceViewController.m
//  localNotifications
//  Created by jayati on 7/19/16.
//  Copyright © 2016 com.zapsolution. All rights reserved.
//

#import "practiceViewController.h"

@interface practiceViewController ()

@end

@implementation practiceViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnClick:(id)sender {
    UILocalNotification* local = [[UILocalNotification alloc]init];
    if (local) {
        local.fireDate = [NSDate dateWithTimeIntervalSinceNow:5];
        local.alertBody = @"Hey this is my first local notification!!!";
        local.alertLaunchImage = @"sachin.png";
        local.soundName = @"sachin.mp3";
        //local.timeZone = [NSTimeZone defaultTimeZone];
        [[UIApplication sharedApplication] scheduleLocalNotification:local];

    }
    
}
@end
