//
//  practiceViewController.h
//  localNotifications
//  Created by jayati on 7/19/16.
//  Copyright © 2016 com.zapsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface practiceViewController : UIViewController
- (IBAction)btnClick:(id)sender;

@end
