//
//  main.m
//  localNotifications
//  Created by jayati on 7/19/16.
//  Copyright © 2016 com.zapsolution. All rights reserved.
//


#import <UIKit/UIKit.h>

#import "practiceAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([practiceAppDelegate class]));
    }
}
