//
//  SearchViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher
import Toaster

var strCat : String = "All Categories"
var strCatID : String = String()
var strPostID : String = String()

class SearchViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var lblConnection: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet var tblContents : UITableView!
    var arrAds = [[String:AnyObject]]()
    var arrFav : NSArray! = NSArray()
    let adDic : NSDictionary! = NSDictionary()
    var strCate : String = String()
    var strPath : String = String()
    var id : Int = 0
    var urlImg : String = String()
    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblContents.dataSource = self
        self.navigationItem.title = "Search"
        refreshControl.addTarget(self, action: #selector(SearchViewController.refresh), for: UIControlEvents.valueChanged)
        tblContents.addSubview(refreshControl)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.fetchAllPost()
        self.navigationItem.title = "Search"
        self.lblCategory.text = strCat
        self.segmentControl.selectedSegmentIndex = 0
    }
   
    func searchDisplayController(_ controller: UISearchDisplayController, didLoadSearchResultsTableView tableView: UITableView) {
        tableView.rowHeight = 90.0
    }
    
    func refresh() {
        self.fetchAllPost()
        self.segmentControl.selectedSegmentIndex = 0
        refreshControl.endRefreshing()
    }
    
    func fetchAllPost() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_fetchposts", method: .post, parameters: ["cat_id" : strCatID , "post_id" : strPostID]).responseJSON { (responseData) -> Void in
                print(responseData)
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value! as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        let tempArr1 = dic["path"]!
                        print(tempArr1)
                        self.strPath = tempArr1 as! String
                        let tempArr = dic["data"]! as! [AnyObject]
                        self.arrAds = tempArr as! [[String : AnyObject]]
                        print(self.arrAds)
                        self.lblConnection.isHidden = true
                        self.segmentControl.isHidden = false
                        self.tblContents.isHidden = false
                        self.tblContents.reloadData()
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        self.lblConnection.isHidden = true
                        self.segmentControl.isHidden = true
                        self.tblContents.isHidden = true
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.dismiss(animated: true, completion: nil);
                    }
                }
                else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else {
            print("disConnected")
            self.segmentControl.isHidden = true
            self.lblConnection.isHidden = false
            self.tblContents.isHidden = true
            self.lblConnection.text = "No Internet connection available"
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAds.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : ClassifiedListTableViewCell!
        cell = tblContents.dequeueReusableCell(withIdentifier: "CellClassified") as! ClassifiedListTableViewCell
        let adDic = arrAds[indexPath.row]
        cell.adTitleLbl.text = adDic["title"] as? String
        let cost : String = (adDic["price"] as? String)!
        cell.adPriceLbl.text = "$\(cost)"
        cell.adAuthorLbl.text = adDic["author"] as? String
        let myDate : String = (adDic["created"] as? String)!
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let datee = dateFormat.date(from: myDate)
        dateFormat.dateFormat =  "MMM dd yyyy"
        let  newDate =  dateFormat.string(from: datee!)
        cell.adDateLbl.text = newDate
        urlImg = strPath.appending((adDic["image"] as? String)!)
        let catPictureURL = URL(string: urlImg)!
            if catPictureURL != nil {
                cell.adImgView.kf.setImage(with: (with: catPictureURL),
                                           placeholder: UIImage(named: "placeholder"),
                                           options: nil)
           }
            else {
                cell.adImgView.image = UIImage(named: "placeholder")
       }        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        newViewController.id = (arrAds[indexPath.row] )["id"] as! String
        newViewController.desc = (arrAds[indexPath.row] )["description"] as! String
        newViewController.price = (arrAds[indexPath.row] )["price"] as! String
        newViewController.category = (arrAds[indexPath.row] )["title"] as! String
        newViewController.date = (arrAds[indexPath.row] )["created"] as! String
        newViewController.titleDetail = (arrAds[indexPath.row] )["added_by_name"] as! String
        newViewController.strImg = strPath.appending((arrAds[indexPath.row] )["image"] as! String)
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    
    
    @IBAction func onBtnSetting(_ sender: AnyObject) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "CategoriesViewController") as! CategoriesViewController
        self .present(newViewController, animated: true, completion: nil)
    }
    
    @IBAction func onBtnFilterTapped(_ sender: AnyObject) {
 
    }
    
    @IBAction func indexChanged(_ sender: AnyObject) {
        switch segmentControl.selectedSegmentIndex
        {
        case 0:
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            arrAds = arrAds.sorted {
                (dictOne, dictTwo) -> Bool in
                let d1 = dateFormatter.date(from: (dictOne["created"]! as! String))
                let d2 = dateFormatter.date(from: (dictTwo["created"]! as! String))
                return d1! > d2!
            }
           tblContents.reloadData()
            break
            
        case 1:
            arrAds = arrAds.sorted {
                (dictOne, dictTwo) -> Bool in
                let d1 = Double(dictOne["price"]! as! String)!
                let d2 = Double(dictTwo["price"]! as! String)!
                return d1 < d2
                } 
            tblContents.reloadData()
            break
            
        default:
            break
        }
    }
    
}
