//
//  EditProfileController.swift
//  classified
//
//  Created by ami on 3/27/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster

class EditProfileController: UIViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    var StrUserID : NSString = NSString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Edit Profile"
        let paddingView = UIView(frame:CGRect(x:0, y:0, width:5, height:30))
        txtFirstName.leftView=paddingView;
        txtFirstName.leftViewMode = UITextFieldViewMode.always
        let paddingView1 = UIView(frame:CGRect(x:0, y:0, width:5, height:30))
        txtLastName.leftView=paddingView1;
        txtLastName.leftViewMode = UITextFieldViewMode.always
        let paddingView2 = UIView(frame:CGRect(x:0, y:0, width:5, height:30))
        txtEmail.leftView=paddingView2;
        txtEmail.leftViewMode = UITextFieldViewMode.always
        txtEmail.textColor = UIColor.lightGray
        self.FetchUser()
    }
    @IBAction func btnBackTapped(_ sender: AnyObject) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func FetchUser() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
        MBProgressHUD.showAdded(to: self.view, animated: true)
        Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_fetchuser", method: .post, parameters:["user_id" : StrUserid]).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let dic = responseData.result.value as! NSDictionary
                if (dic["code"]!) as! Int == 1
                {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic1 = (dic["data"] as! NSArray)[0] as! [String:Any]
                    print(dic1["last_name"])
                    self.txtLastName.text = (dic1["last_name"]! as! String)
                    self.txtFirstName.text = (dic1["first_name"]! as! String)
                    self.txtEmail.text = (dic1["email_id"]! as! String)
                }
                else{
                    MBProgressHUD.hide(for: self.view, animated: true)
                    Toast(text: (dic["mesasge"]!) as? String , duration: Delay.short).show()
                    self.dismiss(animated: true, completion: nil);
                }
            }
        }
    }
            else {
                print("disConnected")
                Toast(text: "No Internet connection available" , duration: Delay.short).show()
    }
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.tintColor = UIColor (colorLiteralRed:193.0/255.0 , green: 42.0/255.0, blue: 48.0/255.0, alpha: 1)
    }
    
    @IBAction func btnUpdateProfileTapped(_ sender: AnyObject) {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            if (self.txtFirstName.text?.isEmpty)! || ((txtFirstName.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) || !(checkUserName(txtFirstName.text!)) || !(validateFname(fname: self.txtFirstName.text!)) {
                print("enter valid name")
                Toast(text: "Please enter valid first name" , duration: Delay.short).show()
            }
            else if (((self.txtFirstName.text?.characters.count)! > 20) || ((self.txtFirstName.text?.characters.count)! < 3)) {
                Toast(text: "Firstname must be in length of min 3 and max 20 characters" , duration: Delay.short).show()
            }
            else if (self.txtLastName.text?.isEmpty)! || ((txtLastName.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) || !(checkUserName(txtLastName.text!)) || !(validateFname(fname: self.txtLastName.text!)) {
                Toast(text: "Please enter valid last name" , duration: Delay.short).show()
            }
            else if (((self.txtLastName.text?.characters.count)! > 20) || ((self.txtLastName.text?.characters.count)! < 3)) {
                Toast(text: "Lastname must be in length of min 3 and max 20 characters" , duration: Delay.short).show()
            }
            else if (self.txtEmail.text?.isEmpty)! {
                Toast(text: "Email is required" , duration: Delay.short).show()
            }
            else if !self.isValidEmail(testStr: self.txtEmail.text!) || (self.txtEmail.text != self.txtEmail.text?.lowercased()) ||  ((txtEmail.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) || !(checkUserName(txtEmail.text!)){
                Toast(text: "Email is invalid" , duration: Delay.short).show()
            }
            else {
                self.updateUser()
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField.returnKeyType==UIReturnKeyType.next) {
            textField.superview?.viewWithTag(textField.tag+1)?.becomeFirstResponder()
        }
        else if (textField.returnKeyType==UIReturnKeyType.done) {
            textField.resignFirstResponder();
        }
        return true;
    }
    
    func checkUserName(_ stringName:String) -> Bool {
        var sepcialChar = false
        var temp = false
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789")
        if stringName.rangeOfCharacter(from: characterset.inverted) != nil {
            print("string contains special characters")
            sepcialChar = true
        }
        else {
            temp = true
        }
        let phone = stringName.components(separatedBy: CharacterSet.decimalDigits.inverted).joined(separator: "")
        if phone != "" || sepcialChar == true {
            temp = false
            for chr in stringName.characters {
                if ((chr >= "a" && chr <= "z") || (chr >= "A" && chr <= "Z") ) {
                    temp = true
                    break
                }
            }
        }
        if temp == true {
            return true
        }
        else {
            return false
        }
    }
    
    
    func validateFname(fname: String) -> Bool {
        let nameRegex = "^[A-Za-z]+[a-zA-Z0-9'_.-]*$"
        let nameTest = NSPredicate(format: "SELF MATCHES %@", nameRegex)
        let result3 = nameTest.evaluate(with: fname)
        return result3
    }
    
    func isValidEmail(testStr:String) -> Bool {
        print("validate emilId: \(testStr)")
        let emailRegEx = "[A-Za-z0-9.]+[A-Za-z]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with:testStr)
        return result
    }

    func updateUser() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_updateuser", method: .post, parameters:["user_id" : StrUserid ,"first_name" : self.txtFirstName.text! , "email_id" : self.txtEmail.text!, "last_name" : self.txtLastName.text!]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.navigationController?.popViewController(animated: true)
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.dismiss(animated: true, completion: nil);
                    }
                } else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }

}
