//
//  CategoriesViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster
var arrCatID = NSMutableArray()
var arrCatName = NSMutableArray()

class CategoriesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var btnCancel: UIButton!
    var arrCategories : NSArray! = NSArray()
    @IBOutlet var tblContents: UITableView!
    var StrUserID : NSString = NSString()
    var isSelectedCat = false
    var isCategory = true
    var i = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblContents.delegate = self
        self.tblContents.dataSource = self
        i = arrCatID.count
        self.fetchAllCategories()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func fetchAllCategories() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_fetchallcategories", method: .post, parameters:["user_id" : StrUserid]).responseJSON { (responseData) -> Void in
                print(responseData)
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        let tempArr = dic["data"]! as! [AnyObject]
                        self.arrCategories = tempArr as NSArray
                        print(self.arrCategories)
                        self.tblContents.reloadData()
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.dismiss(animated: true, completion: nil);
                    }
                } else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCategories.count + 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : CategoryTableViewCell!
        cell = tblContents.dequeueReusableCell(withIdentifier: "CellCategory") as! CategoryTableViewCell
        if (indexPath.row == 0) {
            cell.lblTitle.text = "All Categories"
            if isCategory == true && arrCatID.count == 0
            {
                cell.accessoryType = UITableViewCellAccessoryType.checkmark
                cell.lblTitle.textColor = UIColor.red
                strCat = cell.lblTitle.text!
                isCategory = false
            }
        } else {
             let adDic : NSDictionary = arrCategories.object(at: indexPath.row - 1)  as! NSDictionary
            for i in 0 ..< arrCatID.count
            {
            if arrCatID[i] as? String == adDic["id"] as? String {
                cell.accessoryType = UITableViewCellAccessoryType.checkmark
                cell.lblTitle.textColor = UIColor.red
            }
            }
            cell.lblTitle.text = adDic["name"] as? String
        }
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var cell : CategoryTableViewCell!
        cell = tblContents.cellForRow(at: indexPath) as! CategoryTableViewCell
        let selectedRow:CategoryTableViewCell = tableView.cellForRow(at: indexPath)! as! CategoryTableViewCell
        let indexPath1 = IndexPath(item: 0, section: 0)
        let selectedRow1 :CategoryTableViewCell = tableView.cellForRow(at: indexPath1)! as! CategoryTableViewCell
        if selectedRow.accessoryType == UITableViewCellAccessoryType.none {
            isSelectedCat = true
            if indexPath.row != 0
            {
                i += 1
                isCategory = false
                selectedRow1.accessoryType =  UITableViewCellAccessoryType.none
                selectedRow1.lblTitle.textColor = UIColor.darkGray
                selectedRow.accessoryType = UITableViewCellAccessoryType.checkmark
                let adDic : NSDictionary = arrCategories.object(at: indexPath.row - 1)  as! NSDictionary
                arrCatName.add(((adDic as! [String: AnyObject])["name"] as! String))
                strCat = ((arrCatName as NSArray as? [String])?.joined(separator:","))!
                arrCatID.add(((adDic as! [String: AnyObject])["id"] as! String))
            }
            else  if indexPath.row == 0 {
                selectedRow1.accessoryType = UITableViewCellAccessoryType.checkmark
                selectedRow1.lblTitle.textColor = UIColor.red
                i = 0
                arrCatID = NSMutableArray()
                arrCatName = NSMutableArray()
                strCat = "All Categories"
                for i in 1 ... arrCategories.count {
                    let indexPath1 = IndexPath(item: i, section: 0)
                    let selectedRow1 :CategoryTableViewCell = tableView.cellForRow(at: indexPath1)! as! CategoryTableViewCell
                    selectedRow1.accessoryType =  UITableViewCellAccessoryType.none
                    selectedRow1.lblTitle.textColor = UIColor.darkGray
                }
            }
            cell.lblTitle.textColor = UIColor.red
        }
        else {
            if indexPath.row != 0
            {
                let adDic : NSDictionary = arrCategories.object(at: indexPath.row - 1)  as! NSDictionary
                arrCatName.remove(((adDic as! [String: AnyObject])["name"] as! String))
                strCat = ((arrCatName as NSArray as? [String])?.joined(separator:","))!
                arrCatID.remove(((adDic as! [String: AnyObject])["id"] as! String))
            }
            i -= 1
            selectedRow.accessoryType = UITableViewCellAccessoryType.none
            selectedRow.lblTitle.textColor = UIColor.darkGray
        }
        if i == arrCategories.count {
            selectedRow1.accessoryType = UITableViewCellAccessoryType.checkmark
            selectedRow1.lblTitle.textColor = UIColor.red
            i = 0
            arrCatID = NSMutableArray()
            arrCatName = NSMutableArray()
            strCat = "All Categories"
            for i in 1 ... arrCategories.count {
                let indexPath1 = IndexPath(item: i, section: 0)
                let selectedRow1 :CategoryTableViewCell = tableView.cellForRow(at: indexPath1)! as! CategoryTableViewCell
                selectedRow1.accessoryType =  UITableViewCellAccessoryType.none
                selectedRow1.lblTitle.textColor = UIColor.darkGray
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
    }
    
    @IBAction func dismissView() {
        strCatID = ((arrCatID as NSArray as? [String])?.joined(separator:","))!
        self.dismiss(animated: true, completion: nil)
    }
}
