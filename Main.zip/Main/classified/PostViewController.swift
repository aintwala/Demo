//
//  PostViewController.swift
//  classified
//
//  Created by ami on 3/24/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster


class PostViewController: UIViewController, UIPickerViewDelegate {

    @IBOutlet weak var txtview: UIView!
    @IBOutlet weak var dataPickerView: UIImageView!
    @IBOutlet weak var btnOK: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var dataPicker: UIPickerView!
    @IBOutlet weak var imgViewBG: UIImageView!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var nextArrow: UIImageView!
    @IBOutlet weak var btnCategory: UIButton!
    var arrCategories : NSArray = NSArray()
    var StrUserID : NSString = NSString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataPicker.isHidden = true
        self.btnOK.isHidden = true
        self.btnCancel.isHidden = true
        self.dataPickerView.isHidden = true
        self.navigationController?.isNavigationBarHidden = true
        self.dataPicker.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        self.dataPicker.isHidden = true
        self.btnOK.isHidden = true
        self.btnCancel.isHidden = true
        self.dataPickerView.isHidden = true
        self.imgViewBG.isHidden = false
        self.lblCategory.isHidden = false
        self.nextArrow.isHidden = false
        self.btnCategory.isHidden = false
        self.lblCategory.isHidden = false
        self.txtview.isHidden = false
    }
    
    
    @IBAction func btnCategoryTapped(_ sender: AnyObject) {
        self.dataPicker.isHidden = false
        self.btnOK.isHidden = false
        self.btnCancel.isHidden = false
        self.dataPickerView.isHidden = false
        self.imgViewBG.isHidden = true
        self.lblCategory.isHidden = true
        self.nextArrow.isHidden = true
        self.btnCategory.isHidden = true
        self.txtview.isHidden = true
        self.fetchAllCategories()
    }

    @IBAction func btnCancelTapped(_ sender: AnyObject) {
        self.dataPicker.isHidden = true
        self.btnOK.isHidden = true
        self.btnCancel.isHidden = true
        self.dataPickerView.isHidden = true
        self.imgViewBG.isHidden = false
        self.lblCategory.isHidden = false
        self.nextArrow.isHidden = false
        self.btnCategory.isHidden = false
        self.lblCategory.isHidden = false
        self.txtview.isHidden = false
    }
    
    func fetchAllCategories() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_fetchallcategories", method: .post, parameters:["user_id" : StrUserid]).responseJSON { (responseData) -> Void in
                print(responseData)
                if((responseData.result.value) != nil) {
                     MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        let tempArr = dic["data"]! as! [AnyObject]
                        self.arrCategories = tempArr as NSArray
                        print(self.arrCategories)
                        self.dataPicker.reloadAllComponents()
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.dismiss(animated: true, completion: nil);
                    }
                }
                else
                {
                     MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    
    @IBAction func btnOKTapped(_ sender: AnyObject) {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
        let num : Int = dataPicker.dataSource!.numberOfComponents(in: dataPicker)
        var selectRow: Int = 0
        for i in 0..<num {
             selectRow = dataPicker.selectedRow(inComponent: i)
        }
        let tempDic = self.arrCategories[selectRow] as! [String:AnyObject]
        cat_id = tempDic["id"]! as! String
        print(cat_id)
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "AddInfoViewController") as! AddInfoViewController
        self.navigationController?.pushViewController(newViewController, animated: true)
        }
    else {
        print("disConnected")
        Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func numberOfComponentsInPickerView(_ pickerView: UIPickerView!) -> Int
    {
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView!, numberOfRowsInComponent component: Int) -> Int
    {
        return arrCategories.count;
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        let tempDic = self.arrCategories[row] as! [String:AnyObject]
        return tempDic["name"]! as? String
    }
}
