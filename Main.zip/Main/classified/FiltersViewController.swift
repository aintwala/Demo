//
//  FiltersViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit

class FiltersViewController: UIViewController {

    @IBOutlet var pickerView:UIPickerView!
    var arrCategories : NSArray!
    @IBOutlet var lblCategory : UILabel!
    @IBOutlet var viewForPicker : UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.backBarButtonItem?.isEnabled = true
        arrCategories = ["All categories","Car","Sport & Hobby","Apartment/Rents","Rooms/Beds","Bike & Scooter","Jobs & Services","Offices & Commercial","Phones & Photography","Appliances","Boating"]
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showRangeView() {
        viewForPicker.frame = CGRect(x: 0, y: self.view.frame.size.height, width: 320, height: viewForPicker.frame.size.height);
            viewForPicker.isHidden = false
            UIView.animate(withDuration: 0.5, delay: 0, options:[], animations: {
                self.viewForPicker.frame = CGRect(x: self.viewForPicker.frame.origin.x, y: self.view.frame.size.height - self.viewForPicker.frame.size.height, width: 320, height: self.viewForPicker.frame.size.height);
                }, completion: nil)
            
        
    }
    
    @IBAction func hideRangeView() {
        
        UIView.animate(withDuration: 1, delay: 0, options:[], animations: {
            self.viewForPicker.isHidden = true
            self.viewForPicker.frame = CGRect(x:0, y:self.view.frame.size.height, width:320, height:self.viewForPicker.frame.size.height);
            }, completion: nil)
    }
    
    func numberOfComponentsInPickerView(_ pickerView: UIPickerView!) -> Int
    {
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView!, numberOfRowsInComponent component: Int) -> Int
    {
        return arrCategories!.count;
    }
    
    func pickerView(_ pickerView: UIPickerView!, titleForRow row: Int, forComponent component: Int) -> String
    {
        return arrCategories![row] as! String
    }
    
    func pickerView(_ pickerView: UIPickerView!, didSelectRow row: Int, inComponent component: Int)
    {
        lblCategory.text = arrCategories![row] as? String
    }
    
    @IBAction func dismissView() {
        self.dismiss(animated: true, completion: nil)
    }

}
