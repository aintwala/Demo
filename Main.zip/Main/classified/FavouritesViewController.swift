//
//  FavouritesViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher
import Toaster

class FavouritesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var lblFav: UILabel!
    @IBOutlet var tblContents : UITableView!
    var arrAds = [[String:AnyObject]]()
    var StrUserID : NSString = NSString()
    var strPath : String = String()
    var urlImg : String = String()
    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblContents.dataSource = self
        self.tblContents.delegate = self
        refreshControl.addTarget(self, action: #selector(FavouritesViewController.refresh), for: UIControlEvents.valueChanged)
        tblContents.addSubview(refreshControl)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func  refresh() {
        self.fetchAllFav()
        self.segmentControl.selectedSegmentIndex = 0
        refreshControl.endRefreshing()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden =  false
        arrAds = [[String:AnyObject]]()

        self.fetchAllFav()
        self.tblContents.reloadData()
    }

    func fetchAllFav() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_getallfavourites", method: .post, parameters:["user_id" : StrUserid])
                .responseJSON { (responseData) -> Void in
                    print(responseData)
                    if((responseData.result.value) != nil) {
                        MBProgressHUD.hide(for: self.view, animated: true)
                        let dic = responseData.result.value as! NSDictionary
                        if (dic["code"]!) as! Int == 1
                        {
                            let tempArr1 = dic["path"]!
                            print(tempArr1)
                            self.strPath = tempArr1 as! String
                            let tempArr = dic["data"]! as! [AnyObject]
                            self.arrAds = tempArr as [AnyObject] as! [[String : AnyObject]]
                            print(self.arrAds)
                            self.lblFav.isHidden = true
                            self.tblContents.isHidden = false
                            self.segmentControl.isHidden = false
                            self.tblContents.reloadData()
                        }
                        else {
                            MBProgressHUD.hide(for: self.view, animated: true)
                            self.tblContents.reloadData()
                            self.tblContents.isHidden = true
                            self.segmentControl.isHidden = true
                            self.lblFav.isHidden = false
                            self.lblFav.text = dic["message"] as? String
                            Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        }
                    }
                }
        } 
            else {
            print("disConnected")
            self.lblFav.text = "No Internet connection available"
            self.segmentControl.isHidden = true
            self.tblContents.isHidden = true
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAds.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {        var cell : ClassifiedListTableViewCell!
        cell = tblContents.dequeueReusableCell(withIdentifier: "CellClassified") as! ClassifiedListTableViewCell
        let adDic : NSDictionary = arrAds[indexPath.row] as! [String : String] as NSDictionary
        cell.adTitleLbl.text = adDic["title"] as? String
        let myDate : String = (adDic["created"] as? String)!
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let datee = dateFormat.date(from: myDate)
        dateFormat.dateFormat =  "MMM dd yyyy"
        let  newDate =  dateFormat.string(from: datee!)
        cell.adDateLbl.text = newDate
        cell.adAuthorLbl.text = adDic["author"] as? String
        let cost : String = (adDic["price"] as? String)!
        cell.adPriceLbl.text = "$\(cost)"
        urlImg = strPath.appending((adDic["image"] as? String)!)
        let catPictureURL = URL(string: urlImg)!
        if catPictureURL != nil {
            cell.adImgView.kf.setImage(with: (with: catPictureURL),
                                       placeholder: UIImage(named: "placeholder"),
                                       options: nil)
        }
        else {
            cell.adImgView.image = UIImage(named: "placeholder")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        newViewController.id = (arrAds[indexPath.row] )["id"] as! String
        newViewController.desc = (arrAds[indexPath.row] )["description"] as! String
        newViewController.price = (arrAds[indexPath.row] )["price"] as! String
        newViewController.category = (arrAds[indexPath.row] )["title"] as! String
        newViewController.date = (arrAds[indexPath.row] )["created"] as! String
        newViewController.titleDetail = (arrAds[indexPath.row] )["added_by_name"] as! String
        newViewController.strImg = strPath.appending((arrAds[indexPath.row] )["image"] as! String)
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    
    @IBAction func btnEdit(_ sender: UIBarButtonItem) {
        if(self.tblContents.isEditing == true) {
            self.tblContents.isEditing = false
            self.navigationItem.rightBarButtonItem?.title = "Edit"
        }
        else {
            self.tblContents.isEditing = true
            self.navigationItem.rightBarButtonItem?.title = "Done"
        }
    }
    
    @IBAction func segmentControlAction(_ sender: AnyObject) {
        switch segmentControl.selectedSegmentIndex
        {
        case 0:
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            arrAds = arrAds.sorted {
                (dictOne, dictTwo) -> Bool in
                let d1 = dateFormatter.date(from: (dictOne["created"]! as! String))
                let d2 = dateFormatter.date(from: (dictTwo["created"]! as! String))
                return d1! > d2!
            }
            tblContents.reloadData()
            break
            
        case 1:
            arrAds = arrAds.sorted {
                (dictOne, dictTwo) -> Bool in
                let d1 = Int(dictOne["price"]! as! String)!
                let d2 = Int(dictTwo["price"]! as! String)!
                return d1 < d2
            }
            tblContents.reloadData()
            break
            
        default:
            break
        }
    }
}

