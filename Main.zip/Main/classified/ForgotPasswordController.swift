//
//  ForgotPasswordController.swift
//  classified
//
//  Created by ami on 3/23/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster

class ForgotPasswordController: UIViewController {

    @IBOutlet weak var txtForgotPass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Forgot Password"
        let paddingView = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtForgotPass.leftView=paddingView;
        txtForgotPass.leftViewMode = UITextFieldViewMode.always
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField.returnKeyType==UIReturnKeyType.next) {
            textField.superview?.viewWithTag(textField.tag+1)?.becomeFirstResponder()
        }
        else if (textField.returnKeyType==UIReturnKeyType.done) {
            textField.resignFirstResponder();
        }
        return true;
    }
    
    @IBAction func btnGetNewPassAction(_ sender: AnyObject) {
        
        
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            if (self.txtForgotPass.text?.isEmpty)! || !self.isValidEmail(testStr: self.txtForgotPass.text!) || (self.txtForgotPass.text != self.txtForgotPass.text?.lowercased()) || ((self.txtForgotPass.text?.characters.count)! > 30) || ((self.txtForgotPass.text?.characters.count)! < 3) || ((txtForgotPass.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "Email is invalid" , duration: Delay.short).show()
            }
            else {
                self.ForgotWebServices()
            }
        }
        else {
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func ForgotWebServices() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request( "http://216.55.169.45/~classifieds/master/api/ws_forgotpwd", method: .post, parameters:["email_id" : self.txtForgotPass.text!]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                     MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["status"]!)as! String == "Success"
                    {
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.navigationController?.popViewController(animated: true)
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                    }
                } else {
                     MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    @IBAction func btnBackTapped(_ sender: AnyObject) {
      _ = self.navigationController?.popViewController(animated: true)
    }
    
    func isValidEmail(testStr:String) -> Bool {
        print("validate emilId: \(testStr)")
        let emailRegEx = "[A-Za-z0-9.]+[A-Za-z]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with:testStr)
        return result
    }
}
