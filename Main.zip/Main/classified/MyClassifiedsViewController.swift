//
//  MyClassifiedsViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit
import TwitterKit
import Alamofire
import Toaster

var StrType : NSString = NSString()
var isSocial = false

class MyClassifiedsViewController: UIViewController {

    @IBOutlet weak var txtSocialEmail: UITextField!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var popUp: UIView!
    @IBOutlet var txtUsername : UITextField!
    @IBOutlet var txtPassword : UITextField!
    @IBOutlet var signUpBtn : UIButton!
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var btnClosePopUp: UIButton!
    @IBOutlet weak var btn_box: UIButton!
    @IBOutlet weak var btnSocialSignIn: UIButton!
    
    var StrUserID : NSString = NSString()
    var StrSocialEmail : String = String()
    var StrSocialUserID : String = String()
    var isRememberMeClicked = true
    var isvalidPass = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.popUp.isHidden = true
        self.lblEmail.isHidden = true
        self.txtSocialEmail.isHidden = true
        self.btnSocialSignIn.isHidden = true
        self.btnClosePopUp.isHidden = true
        self.navigationItem.title = "My Classified"
        txtUsername.autocapitalizationType = UITextAutocapitalizationType.none
        let paddingView = UIView(frame:CGRect(x:0, y:0, width:2, height:30))
        txtUsername.leftView=paddingView;
        txtUsername.leftViewMode = UITextFieldViewMode.always
        let paddingView1 = UIView(frame:CGRect(x:0, y:0, width:2, height:30))
        txtPassword.leftView=paddingView1;
        txtPassword.leftViewMode = UITextFieldViewMode.always
        let paddingView2 = UIView(frame:CGRect(x:0, y:0, width:2, height:30))
        txtSocialEmail.leftView=paddingView2;
        txtSocialEmail.leftViewMode = UITextFieldViewMode.always
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if  (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.paramEmail) as? String) != nil && (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.paramPassword) as? String) != nil {
            txtUsername.text = (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.paramEmail) as? String)!
            txtPassword.text = (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.paramPassword) as? String)!
        }
        if (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.issignedin) as? String) != nil {
            if (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.issignedin) as? String)! == "YES"
            {
                btn_box.setImage(UIImage(named: "check"), for: .normal)
                isRememberMeClicked = false
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField.returnKeyType==UIReturnKeyType.next) {
            textField.superview?.viewWithTag(textField.tag+1)?.becomeFirstResponder()
        }
        else if (textField.returnKeyType==UIReturnKeyType.done) {
            textField.resignFirstResponder();
        }
        return true;
    }
    
    @IBAction func btnClosePopUpTapped(_ sender: AnyObject) {
        self.popUp.isHidden = true
        self.lblEmail.isHidden = true
        self.txtSocialEmail.isHidden = true
        self.btnSocialSignIn.isHidden = true
        self.btnClosePopUp.isHidden = true
    }
    
    @IBAction func signInBtnTapped(_ sender : UIButton) {
        
        
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
        
        var arrayOfStrings = ["<", ">", "{" , "}" , "[" , "]", "(" , " )" , "%" , "~" , "|" , "/", "?" , "," , "."]
        for i in 0..<arrayOfStrings.count {
            if(txtPassword.text?.contains(arrayOfStrings[i] as String))!{
                isvalidPass = true
            }
        }
        if (self.txtUsername.text?.isEmpty)! {
            Toast(text: "Email is required" , duration: Delay.short).show()
        }
        else if !self.isValidEmail(testStr: self.txtUsername.text!) || (self.txtUsername.text != self.txtUsername.text?.lowercased()) ||  ((txtUsername.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) || !(checkUserName(txtUsername.text!)){
            Toast(text: "Email is invalid" , duration: Delay.short).show()
        }
        else if (self.txtPassword.text?.isEmpty)! {
            Toast(text: "Password is required" , duration: Delay.short).show()
        }
        else if ((txtPassword.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
            Toast(text: "Password is not valid" , duration: Delay.short).show()
        }
        else if isvalidPass == true {
            Toast(text: "Password is not valid" , duration: Delay.short).show()
        }
        else if (((self.txtPassword.text?.characters.count)! < 8) || ((self.txtPassword.text?.characters.count)! > 15)) {
            Toast(text: "Password must be in length of min 8 and max 15 characters" , duration: Delay.short).show()
        }
        else {
            if (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.issignedin) as? String) != nil {
                if (Constants().getUserDefault(KeyToReturnValye: Constants.ApiConstants.issignedin) as? String)! == "YES"
                {
                    Constants().setUserDefault(ObjectToSave: txtUsername.text as AnyObject?, KeyToSave: Constants.ApiConstants.paramEmail)
                    
                    Constants().setUserDefault(ObjectToSave: txtPassword.text as AnyObject?, KeyToSave: Constants.ApiConstants.paramPassword)
                }
            }
            StrType = ""
            self.LoginWebServices()
            }
        }
        else {
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func checkUserName(_ stringName:String) -> Bool {
        var sepcialChar = false
        var temp = false
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789")
        if stringName.rangeOfCharacter(from: characterset.inverted) != nil {
            print("string contains special characters")
            sepcialChar = true
        }
        else {
            temp = true
        }
        let phone = stringName.components(separatedBy: CharacterSet.decimalDigits.inverted).joined(separator: "")
        if phone != "" || sepcialChar == true {
            temp = false
            for chr in stringName.characters {
                if ((chr >= "a" && chr <= "z") || (chr >= "A" && chr <= "Z") ) {
                    temp = true
                    break
                }
            }
        }
        if temp == true {
            return true
        }
        else {
            return false
        }
    }

    @IBAction func signUpBtnTaped(_ sender : UIButton) {
        
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let newViewController = storyBoard.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
            self.view.isUserInteractionEnabled = true
            self.navigationController?.pushViewController(newViewController, animated: true)
        }
        else{
            MBProgressHUD.hide(for: self.view, animated: true)
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
       
    }
    
    func isValidEmail(testStr:String) -> Bool {
        print("validate emilId: \(testStr)")
        let emailRegEx = "[A-Za-z0-9.]+[A-Za-z]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with:testStr)
        return result
    }
    
    @IBAction func onbtnTWLogin(_ sender: AnyObject) {
        isSocial = true
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
           // MBProgressHUD.showAdded(to: self.view, animated: true)
            Twitter.sharedInstance().logIn {
                (session, error) -> Void in
                if (session != nil) {
                    
                    print("signed in as \(session!.userName)")
                    StrType = "twitter"
                    self.StrSocialUserID = session!.userID as String
                    self.StrUserID = self.StrSocialUserID as NSString
                    StrUserid =  self.StrUserID
                    let client = TWTRAPIClient()
                    client.loadUser(withID: (session?.userID)!, completion: { (user, error) -> Void in
                        print("Name: \(user!.name)")
                        print("Image Url: \(user!.profileImageURL)")
                        _ = NSURL(string:  (user!.profileImageURL))
                        self.txtSocialEmail.isHidden = false
                        self.lblEmail.isHidden = false
                        self.btnClosePopUp.isHidden = false
                        self.btnSocialSignIn.isHidden = false
                        self.popUp.isHidden = false
                    })
                }
            }
        }
        else{
            MBProgressHUD.hide(for: self.view, animated: true)
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    @IBAction func onbtnFBLogin(_ sender: AnyObject) {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            let objFBSDKLoginManager : FBSDKLoginManager = FBSDKLoginManager()
            objFBSDKLoginManager.logOut()
            objFBSDKLoginManager.logIn(withReadPermissions: ["email"]) { (result, error) -> Void in
                if (error == nil) {
                    let objLoginResult : FBSDKLoginManagerLoginResult = result!
                    if (result?.isCancelled)! {
                        MBProgressHUD.hide(for: self.view, animated: true)
                        return
                            self.view.isUserInteractionEnabled = true
                    }
                    if (objLoginResult.grantedPermissions.contains("email")) {
                        isSocial = true
                        if ((FBSDKAccessToken.current()) != nil) {
                            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                                if (error == nil) {
                                    let response = result as AnyObject?
                                    let id = response?.object(forKey: "id") as AnyObject?
                                    self.StrSocialUserID = (id as? String)!
                                    print(self.StrSocialUserID)
                                    self.StrUserID = self.StrSocialUserID as NSString
                                    StrUserid =  self.StrUserID
                                    let fnm = response?.object(forKey: "first_name") as AnyObject?
                                    let strFirstName: String = (fnm as? String)!
                                    print(strFirstName)
                                    let lnm = response?.object(forKey: "last_name") as AnyObject?
                                    let strLastName: String = (lnm as? String)!
                                    print(strLastName)
                                    let email = response?.object(forKey: "email") as AnyObject?
                                    self.StrSocialEmail = (email as? String)!
                                    print(self.StrSocialEmail)
                                    let img = ((response?.object(forKey: "picture") as AnyObject?)?.object(forKey: "data") as AnyObject?)?.object(forKey:"url") as AnyObject?
                                    let strPictureURL: String = (img as? String)!
                                    print(strPictureURL)
                                    StrType = "facebook"
                                    self.SocialLoginFB()
                                }
                            })
                        }
                    }
                }
            }
        }
        else{
            MBProgressHUD.hide(for: self.view, animated: true)

            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func LoginWebServices() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request( "http://216.55.169.45/~classifieds/master/api/ws_signin", method: .post, parameters:["email_id" : self.txtUsername.text! ,  "password" : self.txtPassword.text!]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    print(dic["status"]!)
                    if (dic["status"]!)as! String == "Success" {
                        let dic1 = dic["data"] as! NSDictionary
                        self.StrUserID = dic1["id"] as! NSString
                        if self.isRememberMeClicked == false{
                            Constants().setUserDefault(ObjectToSave: self.StrUserID as AnyObject?, KeyToSave: Constants.ApiConstants.ParamuserID)
                            StrType = ""
                        }
                         StrUserid = self.StrUserID
                            MBProgressHUD.hide(for: self.view, animated: true)
                            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let newViewController = storyBoard.instantiateViewController(withIdentifier: "CustomTabbarViewController") as! CustomTabbarViewController
                            self.present(newViewController, animated: false, completion: nil)
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!)as? String , duration: Delay.short).show()
                    }
                }
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
   
    @IBAction func btnSocialTapped(_ sender: AnyObject) {
        let validEmail: Bool = self.isValidEmail(testStr: self.txtSocialEmail.text!)
        if (self.txtSocialEmail.text?.isEmpty)! || !self.isValidEmail(testStr: self.txtSocialEmail.text!) || (self.txtSocialEmail.text != self.txtSocialEmail.text?.lowercased()) || ((self.txtSocialEmail.text?.characters.count)! < 3) || ((txtSocialEmail.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
            print("enter valid email")
            Toast(text: "Email is invalid" , duration: Delay.short).show()
        }
        else if (txtSocialEmail.text == ""){
            Toast(text: "Email is invalid" , duration: Delay.short).show()
        }
        else if (!validEmail){
            Toast(text: "Email is invalid" , duration: Delay.short).show()
        }
        else{
            SocialLoginTW()
        }
    }
    
    @IBAction func btn_box(_ sender: UIButton) {
        if isRememberMeClicked {
            btn_box.setImage(UIImage(named: "check"), for: .normal)
            Constants().setUserDefault(ObjectToSave: txtUsername.text as AnyObject?, KeyToSave: Constants.ApiConstants.paramEmail)
            Constants().setUserDefault(ObjectToSave: "YES" as AnyObject?, KeyToSave: Constants.ApiConstants.issignedin)
            Constants().setUserDefault(ObjectToSave: txtPassword.text as AnyObject?, KeyToSave: Constants.ApiConstants.paramPassword)
            isRememberMeClicked = false
        }
        else{
            Constants().setUserDefault(ObjectToSave: "NO" as AnyObject?, KeyToSave: Constants.ApiConstants.issignedin)
            btn_box.setImage(UIImage(named: "uncheck"), for: .normal)
            isRememberMeClicked = true
        }
   }
    
    func SocialLoginFB() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            //MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request( "http://216.55.169.45/~classifieds/master/api/ws_soclogin", method: .post, parameters:["type" : StrType ,  "social_id" : self.StrSocialUserID , "email_id" : StrSocialEmail]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!)as! Int == 1
                    {
                        MBProgressHUD.hide(for: self.view, animated: true)
                        let dic1 = (dic["data"] as! NSArray)[0] as! [String:Any]
                        print(dic1["id"]!)
                        self.StrUserID = dic1["id"] as! NSString
                        StrUserid = self.StrUserID
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let newViewController = storyBoard.instantiateViewController(withIdentifier: "CustomTabbarViewController") as! CustomTabbarViewController
                        self.present(newViewController, animated: true, completion: nil)
                        self.popUp.isHidden = true
                        self.lblEmail.isHidden = true
                        self.txtSocialEmail.isHidden = true
                        self.btnSocialSignIn.isHidden = true
                        self.btnClosePopUp.isHidden = true
                    }
                    else {
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: dic["message"] as? String , duration: Delay.short).show()
                    }
                }
                else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else {
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func SocialLoginTW() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request( "http://216.55.169.45/~classifieds/master/api/ws_soclogin", method: .post, parameters:["type" : StrType ,  "social_id" : self.StrSocialUserID , "email_id" : txtSocialEmail.text!]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!)as! Int == 1
                    {
                        let dic1 = (dic["data"] as! NSArray)[0] as! [String:Any]
                        print(dic1["id"]!)
                        self.StrUserID = dic1["id"] as! NSString
                        StrUserid =  self.StrUserID
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let newViewController = storyBoard.instantiateViewController(withIdentifier: "CustomTabbarViewController") as! CustomTabbarViewController
                        self.present(newViewController, animated: true, completion: nil)
                        self.popUp.isHidden = true
                        self.lblEmail.isHidden = true
                        self.txtSocialEmail.isHidden = true
                        self.btnSocialSignIn.isHidden = true
                        self.btnClosePopUp.isHidden = true
                    }
                    else {
                        MBProgressHUD.hide(for: self.view, animated: true)
                    }
                }
                else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }

    
    @IBAction func btnForgotPassTapped(_ sender: AnyObject) {
        
    }
}
