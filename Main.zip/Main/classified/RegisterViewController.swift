//
//  RegisterViewController.swift
//  classified
//
//  Created by ami on 3/23/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster

class RegisterViewController: UIViewController {
    
    var isvalidPass = false
    @IBOutlet weak var txtFirstname: UITextField!
    @IBOutlet weak var txtLastname: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "New Account"
        let paddingView = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtFirstname.leftView=paddingView;
        txtFirstname.leftViewMode = UITextFieldViewMode.always
        let paddingView1 = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtLastname.leftView=paddingView1;
        txtLastname.leftViewMode = UITextFieldViewMode.always
        let paddingView2 = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtEmail.leftView=paddingView2;
        txtEmail.leftViewMode = UITextFieldViewMode.always
        let paddingView3 = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtPassword.leftView=paddingView3;
        txtPassword.leftViewMode = UITextFieldViewMode.always
        let paddingView4 = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtConfirmPass.leftView=paddingView4;
        txtConfirmPass.leftViewMode = UITextFieldViewMode.always
    }

    @IBAction func btnBackTapped(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField.returnKeyType==UIReturnKeyType.next) {
            textField.superview?.viewWithTag(textField.tag+1)?.becomeFirstResponder()
        }
        else if (textField.returnKeyType==UIReturnKeyType.done) {
            textField.resignFirstResponder();
        }
        return true;
    }
    
    @IBAction func btnSignupTapped(_ sender: AnyObject) {
        
        
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            var arrayOfStrings = ["<", ">", "{" , "}" , "[" , "]", "(" , " )" , "%" , "~" , "|" , "/", "?" , "," , "."]
            for i in 0..<arrayOfStrings.count {
                if(txtPassword.text?.contains(arrayOfStrings[i] as String))!{
                    isvalidPass = true
                }
            }
            if (self.txtFirstname.text?.isEmpty)! || ((txtFirstname.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) || !(checkUserName(txtFirstname.text!)) || !(validateFname(fname: self.txtFirstname.text!)) {
                print("enter valid name")
                Toast(text: "Please enter valid first name" , duration: Delay.short).show()
            }
            else if (((self.txtFirstname.text?.characters.count)! > 20) || ((self.txtFirstname.text?.characters.count)! < 3)) {
                Toast(text: "Firstname must be in length of min 3 and max 20 characters" , duration: Delay.short).show()
            }
            else if (self.txtLastname.text?.isEmpty)! || ((txtLastname.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) || !(checkUserName(txtLastname.text!)) || !(validateFname(fname: self.txtLastname.text!)) {
                Toast(text: "Please enter valid last name" , duration: Delay.short).show()
            }
            else if (((self.txtLastname.text?.characters.count)! > 20) || ((self.txtLastname.text?.characters.count)! < 3)) {
                Toast(text: "Lastname must be in length of min 3 and max 20 characters" , duration: Delay.short).show()
            }
            else if (self.txtEmail.text?.isEmpty)! {
                Toast(text: "Email is required" , duration: Delay.short).show()
            }
            else if ((txtEmail.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "Whitespaces not allowed" , duration: Delay.short).show()
            }
            else if !self.isValidEmail(testStr: self.txtEmail.text!) || (self.txtEmail.text != self.txtEmail.text?.lowercased()) || !(checkUserName(txtEmail.text!)){
                Toast(text: "Email is invalid" , duration: Delay.short).show()
            }
            else if (self.txtPassword.text?.isEmpty)! {
                Toast(text: "Password is required" , duration: Delay.short).show()
            }
            else if ((txtPassword.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "Whitespaces not allowed" , duration: Delay.short).show()
            }
            else if isvalidPass == true {
                Toast(text: "Password is not valid" , duration: Delay.short).show()
            }
            else if (((self.txtPassword.text?.characters.count)! < 8) || ((self.txtPassword.text?.characters.count)! > 15)) {
                Toast(text: "Password must be in length of min 8 and max 15 characters" , duration: Delay.short).show()
            }
            else if (self.txtConfirmPass.text?.isEmpty)! {
                Toast(text: "Confirm password is required" , duration: Delay.short).show()
            }
            else if ((txtConfirmPass.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "Whitespaces not allowed" , duration: Delay.short).show()
            }
            else if (self.txtPassword.text != self.txtConfirmPass.text) {
                Toast(text: "Password does not match" , duration: Delay.short).show()
            }
            else if (((self.txtConfirmPass.text?.characters.count)! < 8) || ((self.txtConfirmPass.text?.characters.count)! > 15)) {
                Toast(text: "Confirm Password must be in length of min 8 and max 15 characters" , duration: Delay.short).show()
            }
            else {
                RegisterWebServices()
              _ =  self.navigationController?.popViewController(animated: true)
            }
        }
        else {
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }

    func checkUserName(_ stringName:String) -> Bool {
        var sepcialChar = false
        var temp = false
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789")
        if stringName.rangeOfCharacter(from: characterset.inverted) != nil {
            print("string contains special characters")
            sepcialChar = true
        }
        else {
            temp = true
        }
        let phone = stringName.components(separatedBy: CharacterSet.decimalDigits.inverted).joined(separator: "")
        if phone != "" || sepcialChar == true {
            temp = false
            for chr in stringName.characters {
                if ((chr >= "a" && chr <= "z") || (chr >= "A" && chr <= "Z") ) {
                    temp = true
                    break
                }
            }
        }
        if temp == true {
            return true
        }
        else {
            return false
        }
    }
    
    func validateFname(fname: String) -> Bool {
        let nameRegex = "^[A-Za-z]+[a-zA-Z0-9'_.-]*$"
        let nameTest = NSPredicate(format: "SELF MATCHES %@", nameRegex)
        let result3 = nameTest.evaluate(with: fname)
        return result3
    }
    
    func isValidEmail(testStr:String) -> Bool {
        print("validate emilId: \(testStr)")
        let emailRegEx = "[A-Za-z0-9.]+[A-Za-z]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with:testStr)
        return result
    }
    
    func RegisterWebServices() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request( "http://216.55.169.45/~classifieds/master/api/ws_signup", method: .post, parameters:["first_name" : self.txtFirstname.text!,"last_name" : self.txtLastname.text! , "email_id" : self.txtEmail.text!, "password" : self.txtPassword.text!]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["status"]!)as! String == "success"
                    {
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                    }
                }
                else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
}
