//
//  ClassifiedsViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit
import Toaster

class ClassifiedsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var window: UIWindow?
    @IBOutlet weak var lblSecond: UILabel!
    @IBOutlet weak var lblFirst: UILabel!
    @IBOutlet var tblItems : UITableView!
    var items : NSArray! = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        items = ["Cell0", "Cell1","Cell2","Cell3","Cell4","Cell5","Cell6"]
        self.tblItems.dataSource = self;
    }

    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = "";
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    private func numberOfSectionsInTableView(tableView: UITableView!) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {
        let cell = tblItems.dequeueReusableCell(withIdentifier: items.object(at: indexPath.row) as! String)! as UITableViewCell
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tblItems.dequeueReusableCell(withIdentifier: items.object(at: indexPath.row) as! String)! as UITableViewCell
        if (indexPath.row == 0) {
            if StrType == "facebook" || StrType == "twitter" {
                cell.isUserInteractionEnabled = false
            }
            else {
                if ConnectionCheck.isConnectedToNetwork() {
                    print("Connected")
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let newViewController = storyBoard.instantiateViewController(withIdentifier: "EditProfileController") as! EditProfileController
                    self.navigationController?.pushViewController(newViewController, animated: true)
                }
                else{
                    print("disConnected")
                    Toast(text: "No Internet connection available" , duration: Delay.short).show()
                }
            }
        }
        else if (indexPath.row == 1){
            if StrType == "facebook" || StrType == "twitter" {
                cell.isUserInteractionEnabled = false
            }
            else {
                if ConnectionCheck.isConnectedToNetwork() {
                    print("Connected")
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let newViewController = storyBoard.instantiateViewController(withIdentifier: "ChangePasswordController") as! ChangePasswordController
                    self.navigationController?.pushViewController(newViewController, animated: true)
                }
                else{
                    print("disConnected")
                    Toast(text: "No Internet connection available" , duration: Delay.short).show()
                }
            }
        }
        else if (indexPath.row == 2) {
        }
        else if (indexPath.row == 3){
        }
        else if (indexPath.row == 4){
            if ConnectionCheck.isConnectedToNetwork() {
                print("Connected")
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let newViewController = storyBoard.instantiateViewController(withIdentifier: "TermsOfUseController") as! TermsOfUseController
                newViewController.strTitle = "Terms of Use"
                self.navigationController?.pushViewController(newViewController, animated: true)
            }
            else{
                print("disConnected")
                Toast(text: "No Internet connection available" , duration: Delay.short).show()
            }
        }
        else if (indexPath.row == 5){
            if ConnectionCheck.isConnectedToNetwork() {
                print("Connected")
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let newViewController = storyBoard.instantiateViewController(withIdentifier: "TermsOfUseController") as! TermsOfUseController
                newViewController.strTitle = "About Us"
                self.navigationController?.pushViewController(newViewController, animated: true)
            }
            else{
                print("disConnected")
                Toast(text: "No Internet connection available" , duration: Delay.short).show()
            }
        }
        else {
            if ConnectionCheck.isConnectedToNetwork() {
                print("Connected")
                arrCatID = NSMutableArray()
                arrCatName = NSMutableArray()
                strCat = "All Categories"
                let notificationName = Notification.Name("logout")
                NotificationCenter.default.post(name: notificationName, object: nil)
                Constants().setUserDefault(ObjectToSave: "" as AnyObject?, KeyToSave: Constants.ApiConstants.paramPassword)
                if isRememberMe{
                    self.performSegue(withIdentifier: "LogoutSegue", sender: nil)
                }
                else{
                    self.dismiss(animated: true, completion: {});
                    let notificationName = Notification.Name("logout")
                    NotificationCenter.default.post(name: notificationName, object: nil)
                    Constants().setUserDefault(ObjectToSave: "" as AnyObject?, KeyToSave: Constants.ApiConstants.paramPassword)
                }
            }
            else{
                print("disConnected")
                Toast(text: "No Internet connection available" , duration: Delay.short).show()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view :UIView! = UIView(frame: CGRect(x:0, y:0, width:320, height:1))
        return view
    }
}
