//
//  ChangePasswordController.swift
//  classified
//
//  Created by ami on 3/27/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster

class ChangePasswordController: UIViewController {

    @IBOutlet weak var txtOldPassword: UITextField!
    @IBOutlet weak var txtNewPassword: UITextField!
    @IBOutlet weak var txtConfirmNewPassword: UITextField!
    var StrUserID : NSString = NSString()
    var isvalidPass = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Change Password"
        let paddingView = UIView(frame:CGRect(x:0, y:0, width:5, height:30))
        txtOldPassword.leftView=paddingView;
        txtOldPassword.leftViewMode = UITextFieldViewMode.always
        let paddingView1 = UIView(frame:CGRect(x:0, y:0, width:5, height:30))
        txtNewPassword.leftView=paddingView1;
        txtNewPassword.leftViewMode = UITextFieldViewMode.always
        let paddingView2 = UIView(frame:CGRect(x:0, y:0, width:5, height:30))
        txtConfirmNewPassword.leftView=paddingView2;
        txtConfirmNewPassword.leftViewMode = UITextFieldViewMode.always
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.tintColor = UIColor (colorLiteralRed:193.0/255.0 , green: 42.0/255.0, blue: 48.0/255.0, alpha: 1)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField.returnKeyType==UIReturnKeyType.next) {
            textField.superview?.viewWithTag(textField.tag+1)?.becomeFirstResponder()
        }
        else if (textField.returnKeyType==UIReturnKeyType.done) {
            textField.resignFirstResponder();
        }
        return true;
    }
    
    @IBAction func btnUpdatePasswordTapped(_ sender: AnyObject) {
        
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            var arrayOfStrings = ["<", ">", "{" , "}" , "[" , "]", "(" , " )" , "%" , "~" , "|" , "/", "?" , "," , "."]
            for i in 0..<arrayOfStrings.count {
                if(txtConfirmNewPassword.text?.contains(arrayOfStrings[i] as String))! || (txtNewPassword.text?.contains(arrayOfStrings[i] as String))! || (txtOldPassword.text?.contains(arrayOfStrings[i] as String))! {
                    isvalidPass = true
                }
            }
            if (self.txtOldPassword.text?.isEmpty)! {
                Toast(text: "Old Password is required" , duration: Delay.short).show()
            }
            else if ((txtOldPassword.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "Old Password is not valid" , duration: Delay.short).show()
            }
            else if isvalidPass == true {
                Toast(text: "Old Password/New Password/Confirm new Password is not valid" , duration: Delay.short).show()
            }
            else if (((self.txtOldPassword.text?.characters.count)! < 8) || ((self.txtOldPassword.text?.characters.count)! > 15)) {
                Toast(text: "Old Password must be in length of min 8 and max 15 characters" , duration: Delay.short).show()
            }
            else if (self.txtNewPassword.text?.isEmpty)! {
                Toast(text: "NewPassword is required" , duration: Delay.short).show()
            }
            else if ((txtNewPassword.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "NewPassword is not valid" , duration: Delay.short).show()
            }
            else if (((self.txtNewPassword.text?.characters.count)! < 8) || ((self.txtNewPassword.text?.characters.count)! > 15)) {
                Toast(text: " Password must be in length of min 8 and max 15 characters" , duration: Delay.short).show()
            }
            else if (self.txtConfirmNewPassword.text?.isEmpty)! {
                Toast(text: "New Confirm password is required" , duration: Delay.short).show()
            }
            else if ((txtConfirmNewPassword.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
                Toast(text: "New Confirm password is not valid" , duration: Delay.short).show()
            }
            else if (self.txtNewPassword.text != self.txtConfirmNewPassword.text) {
                Toast(text: "Password does not match" , duration: Delay.short).show()
            }
            else if (((self.txtConfirmNewPassword.text?.characters.count)! < 8) || ((self.txtConfirmNewPassword.text?.characters.count)! > 15)) {
                Toast(text: "New Confirm Password must be in length of min 8 and max 15 characters" , duration: Delay.short).show()
            }
            else {
                self.changePassword()
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func isValidPassword(candidate: String) -> Bool {
        let passwordRegex = "^[A-Za-z0-9@#$^&!*:-\\\\+]*$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
        let result1 = passwordTest.evaluate(with: candidate)
        return result1
    }

    @IBAction func btnBackTapped(_ sender: AnyObject) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func changePassword() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_changepassword", method: .post, parameters:["user_id" : StrUserid ,"old_password" : self.txtOldPassword.text! , "new_password" : self.txtNewPassword.text!]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.navigationController?.popViewController(animated: true)
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.dismiss(animated: true, completion: nil);
                    }
                }
                else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
}
