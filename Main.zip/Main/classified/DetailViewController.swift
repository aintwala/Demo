//
//  DetailViewController.swift
//  classified
//
//  Created by Rajkumar Sharma on 16/05/15.
//  Copyright (c) 2015 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher
import Toaster

class DetailViewController: UIViewController,UIScrollViewDelegate {
    
    @IBOutlet weak var detailTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var catName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var btnAdded: UIButton!
    var isFavAdd = true
    open var id : String = String()
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var imgView: UIImageView!
    var StrUserID : NSString = NSString()
    var type : String = String()
    var desc : String = String()
    var price : String = String()
    var date : String = String()
    var category : String = String()
    var titleDetail : String = String()
    var strFav : [String] = []
    var favID : String = String()
    var strImg : String = String()
    var strFavourite : String = String()
    
    
    @IBOutlet weak var btnfav: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.detailTitle.layer.masksToBounds = true
        self.detailTitle.layer.cornerRadius = 5
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.tintColor = UIColor (colorLiteralRed:193.0/255.0 , green: 42.0/255.0, blue: 48.0/255.0, alpha: 1)
        self.txtDescription.text = desc
        let cost : String = price
        self.lblPrice.text = "$\(cost)"
        self.catName.text = category
        let myDate : String = date
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let datee = dateFormat.date(from: myDate)
        dateFormat.dateFormat =  "MMM dd yyyy"
        let  newDate =  dateFormat.string(from: datee!)
        print(newDate)
        self.fetchAllPost()
        self.lblDate.text = "Added \(newDate) by"
        self.detailTitle.text = titleDetail
        let catPictureURL = URL(string: strImg)!
            imgView.kf.setImage(with: (with: catPictureURL),
                                       placeholder: UIImage(named: "placeholder"),
                                       options: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func btnFavAction(_ sender: AnyObject) {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            if isFavAdd == false {
                type = "add"
                self.addORremoveFav()
                isFavAdd = true
            }
            else {
                type = "remove"
                isFavAdd = false
                self.removeFav()
            }
        }
        else {
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func removeFav() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_favourite", method: .post, parameters:["user_id" : StrUserid, "type" : type, "post_id" : id,"fvt_id" : strFavourite]).responseJSON { (responseData) -> Void in
                print(responseData)
                if((responseData.result.value) != nil) {
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!) as! Int == 1 {
                        MBProgressHUD.hide(for: self.view, animated: true)
                        self.btnfav.setBackgroundImage(UIImage(named: "fav"), for: UIControlState.normal)
                    }
                    else{
                    }
                }
            }
        }
        else{
            print("disConnected")
        }
    }
    
    func addORremoveFav() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_favourite", method: .post, parameters:["user_id" : StrUserid, "type" : type, "post_id" : id]).responseJSON { (responseData) -> Void in
                print(responseData)
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        let tempArr = dic["data"]! as! NSDictionary
                        print(tempArr["fvt_id"]!)
                        self.strFavourite = String(describing: tempArr["fvt_id"]!)
                        self.btnfav.setBackgroundImage(UIImage(named: "fav_selected"), for: UIControlState.normal)
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                    }
                }
            }
        }
        else{
            print("disConnected")
        }
    }

    @IBAction func backBtnTapped (_ sender : UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func fetchAllPost() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_fetchposts", method: .post, parameters: ["user_id" :  StrUserid, "post_id" : id]).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value! as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        let tempArr = dic["data"]! as! NSArray
                        print(tempArr)
                        if ((tempArr as NSArray).value(forKey:"fvt_id") as? [String] != nil) {
                            self.strFav = ((tempArr as NSArray).value(forKey: "fvt_id")  as? [String])!
                            print(self.strFav)
                            let str = tempArr.value(forKey:"fvt_id") as! [AnyObject]
                            self.strFavourite = str[0] as! String
                            self.isFavAdd = true
                            self.btnfav.setBackgroundImage(UIImage(named: "fav_selected"), for: UIControlState.normal)
                        }
                        else {
                            self.isFavAdd = false
                            self.btnfav.setBackgroundImage(UIImage(named: "fav"), for: UIControlState.normal)
                        }
                    }
                    else{
                        MBProgressHUD.hide(for: self.view, animated: true)
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        self.dismiss(animated: true, completion: nil);
                    }
                }
                else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
}
