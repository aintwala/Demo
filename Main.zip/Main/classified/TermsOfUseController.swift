//
//  TermsOfUseController.swift
//  classified
//
//  Created by ami on 4/5/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit

class TermsOfUseController: UIViewController {
    
    var strTitle : String = String()
    @IBOutlet weak var lblTitle: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblTitle.text! = strTitle
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.lblTitle.text! = strTitle
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackTapped(_ sender: AnyObject) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
