//
//  AddInfoViewController.swift
//  classified
//
//  Created by ami on 3/27/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Toaster

var cat_id : String!

class AddInfoViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var isPost = false
    @IBOutlet weak var txtView: UITextView!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtDescription: UITextField!
    @IBOutlet weak var txtPrice: UITextField!
    @IBOutlet weak var imgViewPicker: UIImageView!
    var img : UIImage? = nil
    var StrUserID : NSString = NSString()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Ad Information"
        self.navigationController?.isNavigationBarHidden = false
        imgViewPicker.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(imagePick)))
        imgViewPicker.isUserInteractionEnabled = true
        let paddingView = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtTitle.leftView=paddingView;
        txtTitle.leftViewMode = UITextFieldViewMode.always
        let paddingView1 = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtDescription.leftView=paddingView1;
        txtDescription.leftViewMode = UITextFieldViewMode.always
        let paddingView2 = UIView(frame:CGRect(x:0, y:0, width:10, height:30))
        txtPrice.leftView=paddingView2;
        txtPrice.leftViewMode = UITextFieldViewMode.always
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = "";
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField.returnKeyType==UIReturnKeyType.next) {
            textField.superview?.viewWithTag(textField.tag+1)?.becomeFirstResponder()
        }
        else if (textField.returnKeyType==UIReturnKeyType.done) {
            textField.resignFirstResponder();
        }
        return true;
    }
    
    func imagePick() {
        let pickerView = UIImagePickerController()
        pickerView.delegate = self
        pickerView.allowsEditing = false
        let actionSheetControllerIOS8: UIAlertController = UIAlertController(title: "Please select", message: nil, preferredStyle: .actionSheet)
        let cancelActionButton: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            print("Cancel")
        }
        actionSheetControllerIOS8.addAction(cancelActionButton)
        let saveActionButton: UIAlertAction = UIAlertAction(title: "Take Photo", style: .default) { action -> Void in
            print("Take Photo")
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                pickerView.sourceType = .camera
                self.present(pickerView, animated: true, completion: { _ in })
            }
        }
        actionSheetControllerIOS8.addAction(saveActionButton)
        let deleteActionButton: UIAlertAction = UIAlertAction(title: "Camera Roll", style: .default) { action -> Void in
            print("Camera Roll")
            pickerView.sourceType = .photoLibrary
            self.present(pickerView, animated: true, completion: { _ in })
        }
        actionSheetControllerIOS8.addAction(deleteActionButton)
        self.present(actionSheetControllerIOS8, animated: true, completion: nil)
    }

   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
        
        imgViewPicker.contentMode = .scaleAspectFit
        imgViewPicker.image = pickedImage
            img = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnUpdateProfileTapped(_ sender: AnyObject) {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
        let a:Int? = Int(txtPrice.text!)
        MBProgressHUD.showAdded(to: self.view, animated: true)
        self.view.isUserInteractionEnabled = false
        self.txtTitle.text = txtTitle.text?.trimmingCharacters(in: .whitespaces)
        if (self.txtTitle.text?.isEmpty)! {
            print("please enter valid title")
            Toast(text: "Please enter title" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else if (((self.txtTitle.text?.characters.count)! > 15) || ((self.txtTitle.text?.characters.count)! < 3)) {
            Toast(text: "Title must be in length of min 3 and max 15 characters" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else if (self.txtView.text?.isEmpty)! || ((txtView.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
            Toast(text: "Please enter description" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else if (((self.txtView.text?.characters.count)! > 200) || ((self.txtView.text?.characters.count)! < 3)) {
            Toast(text: "Description must be in length of min 3 and max 200 characters" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else if (self.txtPrice.text?.isEmpty)! ||  ((txtPrice.text?.trimmingCharacters(in: .whitespaces).isEmpty)!) {
            Toast(text: "Price is required" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else if (((self.txtPrice.text?.characters.count)! < 1) ||
            ((self.txtPrice.text?.characters.count)! > 10)) {
            Toast(text: "Price must be in length of max 10 digits" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else if (a! <= 0) {
            Toast(text: "Price is not valid" , duration: Delay.short).show()
            self.view.isUserInteractionEnabled = true
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        else {
            self.wsRegisterUser()
        }
    }
        else {
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
    
    func wsRegisterUser() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            let url = URL(string: "http://216.55.169.45/~classifieds/master/api/ws_addpost")
            let request = NSMutableURLRequest(url: url!)
            request.httpMethod = "POST"
            let boundary = generateBoundaryString()
            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            if (imgViewPicker.image == nil)
            {
                return
            }
            let image_data = UIImageJPEGRepresentation(imgViewPicker.image!, 0.5)
            if(image_data == nil)
            {
                return
            }
            let body = NSMutableData()
            let fname = "test.png"
            let mimetype = "image/png"
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"title\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append("\(txtTitle.text!)\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"description\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append("\(txtView.text!)\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"price\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append("\(txtPrice.text!)\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"user_id\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append("\(StrUserid)\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"added_by\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append("\(StrUserid)\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"cat_id\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append("\(cat_id!)\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition:form-data; name=\"image\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append(image_data!)
            body.append("\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
            request.httpBody = body as Data
            let session = URLSession.shared
            let task = session.dataTask(with: request as URLRequest, completionHandler: {
                (
                data, response, error) in
                guard ((data) != nil), let _:URLResponse = response, error == nil else {
                print("error")
                return
                }
                if let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue) {
                    print(dataString)
                    Toast(text: "Post added successfully" , duration: Delay.short).show()
                }
            })
            
             task.resume()
            MBProgressHUD.hide(for: self.view, animated: true)
             self.tabBarController?.selectedIndex = 3
          
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.001) {
                 _ = self.navigationController?.popViewController(animated: false)
            }
        }
        else{
            print("disConnected")
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }
     
    func generateBoundaryString() -> String
    {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    @IBAction func btnBackTapped(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
}
