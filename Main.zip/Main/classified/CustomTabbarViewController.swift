//
//  CustomTabbarViewController.swift
//  Classified
//
//  Created by Rajkumar Sharma on 05/10/14.
//  Copyright (c) 2014 MyAppTemplates. All rights reserved.
//

import UIKit

class CustomTabbarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBar.tintColor = UIColor.red

        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
