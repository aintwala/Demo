//
//  MyPostController.swift
//  classified
//
//  Created by ami on 3/24/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher
import Toaster

class MyPostController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var lblNoDataFound: UILabel!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var tblContent: UITableView!
    var arrAds : [[String:AnyObject]] = []
    let adDic : NSDictionary! = NSDictionary()
    var StrUserID : NSString = NSString()
    var postID : String = String()
    var strPath : String = String()
    var urlImg : String = String()
    var refreshControl = UIRefreshControl()
    @IBOutlet weak var lblCategory: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblContent.dataSource = self
        refreshControl.addTarget(self, action: #selector(MyPostController.refersh), for: UIControlEvents.valueChanged)
        tblContent.addSubview(refreshControl)
        self.tblContent.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.tintColor = UIColor (colorLiteralRed:193.0/255.0 , green: 42.0/255.0, blue: 48.0/255.0, alpha: 1)
        self.navigationItem.title = "My Classifield"
        self.fetchMyPost()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = "";
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func refersh() {
        self.fetchMyPost()
        self.segmentControl.selectedSegmentIndex = 0
        refreshControl.endRefreshing()
    }
    
    func searchDisplayController(_ controller: UISearchDisplayController, didLoadSearchResultsTableView tableView: UITableView) {
        tableView.rowHeight = 90.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAds.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : ClassifiedListTableViewCell!
        cell = tblContent.dequeueReusableCell(withIdentifier: "CellClassified") as! ClassifiedListTableViewCell
        let adDic : NSDictionary = arrAds[indexPath.row] as NSDictionary
        cell.adTitleLbl.text = adDic["title"] as? String
        let myDate : String = (adDic["created"] as? String)!
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let datee = dateFormat.date(from: myDate)
        dateFormat.dateFormat =  "MMM dd yyyy"
        let  newDate =  dateFormat.string(from: datee!)
        cell.adDateLbl.text = newDate
        cell.adAuthorLbl.text = adDic["author"] as? String
        let cost : String = (adDic["price"] as? String)!
        cell.adPriceLbl.text = "$\(cost)"
        urlImg = strPath.appending((adDic["image"] as? String)!)
        let catPictureURL = URL(string: urlImg)!
        if catPictureURL != nil {
            cell.adImgView.kf.setImage(with: (with: catPictureURL),
                                       placeholder: UIImage(named: "placeholder"),
                                       options: nil)
        }
        else {
            cell.adImgView.image = UIImage(named: "placeholder")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        _ = tblContent.dequeueReusableCell(withIdentifier: "CellClassified")! as UITableViewCell
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let newViewController = storyBoard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        newViewController.id = (arrAds[indexPath.row] )["id"] as! String
        newViewController.desc = (arrAds[indexPath.row] )["description"] as! String
        newViewController.price = (arrAds[indexPath.row] )["price"] as! String
        newViewController.category = (arrAds[indexPath.row] )["title"] as! String
        newViewController.date = (arrAds[indexPath.row] )["created"] as! String
        newViewController.titleDetail = (arrAds[indexPath.row] )["added_by_name"] as! String
        newViewController.strImg = strPath.appending((arrAds[indexPath.row] )["image"] as! String)
        self.navigationController?.pushViewController(newViewController, animated: true)
    }

    func fetchMyPost() {
        if ConnectionCheck.isConnectedToNetwork() {
            print("Connected")
            MBProgressHUD.showAdded(to: self.view, animated: true)
            Alamofire.request("http://216.55.169.45/~classifieds/master/api/ws_fetchposts", method: .post, parameters: ["user_id" : StrUserid]).responseJSON { (responseData) -> Void in
                print(responseData)
                if((responseData.result.value) != nil) {
                    MBProgressHUD.hide(for: self.view, animated: true)
                    let dic = responseData.result.value! as! NSDictionary
                    if (dic["code"]!) as! Int == 1
                    {
                        let tempArr1 = dic["path"]!
                        print(tempArr1)
                        self.strPath = tempArr1 as! String
                        let tempArr = dic["data"]! as! [AnyObject]
                        self.arrAds = (tempArr as NSArray) as! [[String : AnyObject]]
                        print(self.arrAds)
                        self.lblNoDataFound.isHidden = true
                        self.segmentControl.isHidden = false
                        self.tblContent.reloadData()
                    }
                    else {
                        MBProgressHUD.hide(for: self.view, animated: true)
                        self.segmentControl.isHidden = true
                        self.lblNoDataFound.text = (dic["message"]!) as? String
                        Toast(text: (dic["message"]!) as? String , duration: Delay.short).show()
                        MBProgressHUD.hide(for: self.view, animated: true)
                    }
                }
            }
        }
        else{
            print("disConnected")
            self.segmentControl.isHidden = true
            self.lblNoDataFound.isHidden = false
            Toast(text: "No Internet connection available" , duration: Delay.short).show()
        }
    }

    @IBAction func segmentControlAction(_ sender: AnyObject) {
        switch segmentControl.selectedSegmentIndex
        {
        case 0:
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            arrAds = arrAds.sorted {
                (dictOne, dictTwo) -> Bool in
                let d1 = dateFormatter.date(from: (dictOne["created"]! as! String))
                let d2 = dateFormatter.date(from: (dictTwo["created"]! as! String))
                return d1! > d2!
            }
            tblContent.reloadData()
            break
            
        case 1:
            arrAds = arrAds.sorted {
                (dictOne, dictTwo) -> Bool in
                
                let d1 = Int(dictOne["price"]! as! String)!
                let d2 = Int(dictTwo["price"]! as! String)!
                return d1 < d2
            }
            tblContent.reloadData()
            break
        default:
            break
        }
    }
}

