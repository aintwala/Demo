//
//  RTRConstants.swift
//  RealTimeReviews
//
//  Created by Zaptech on 9/30/16.
//
//

import Foundation
import UIKit

struct Constants {
    
    // MARK: - Global Constants
    
    // MARK: - Api Parameters
    struct ApiConstants {
       
        static let paramEmail = "emailId"
         static let ParamuserID = "UserId"
    
        static let paramPassword = "password"
        static let paramPostID = "postID"
        static let issignedin = "NO"
        
           }
      func setUserDefault(ObjectToSave : AnyObject?  , KeyToSave : String)
    {
        let defaults = UserDefaults.standard
        
        if (ObjectToSave != nil)
        {
            
            defaults.set(ObjectToSave, forKey: KeyToSave)
        }
        
        UserDefaults.standard.synchronize()
    }
    
    func getUserDefault(KeyToReturnValye : String) -> AnyObject?
    {
        let defaults = UserDefaults.standard
        
        if let name = defaults.value(forKey: KeyToReturnValye)
        {
            return name as AnyObject?
        }
        return nil
    }
}

