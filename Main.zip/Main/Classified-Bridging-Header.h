//
//  Classified-Bridging-Header.h
//  classified
//
//  Created by ami on 3/23/17.
//  Copyright © 2017 MyAppTemplates. All rights reserved.
//

#ifndef Classified_Bridging_Header_h
#define Classified_Bridging_Header_h


#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "MBProgressHUD.h"

#endif /* Classified_Bridging_Header_h */
